import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Chat {

    private static int chatIdCounter = 1;

    private boolean isPrivate;
    private String chatId;
    private String groupName;
    private List<User> participants;
    private List<Message> messages;

    public Chat(boolean isPrivate) {
        this.chatId = "C" + chatIdCounter++;
        this.isPrivate = isPrivate;
        this.participants = new ArrayList<>();
        this.messages = new ArrayList<>();
    }

    public void addMessage(Message message) {
        this.messages.add(message);
    }

    public void addParticipants(User user) {
        if (!participants.contains(user)) {
            participants.add(user);
        }
    }

    public LocalDateTime getLastMessageTime() {
        if (messages == null || messages.isEmpty()) {
            return LocalDateTime.MIN;
        }
        return messages.get(messages.size() - 1).getSentAt();
    }

    public String getDisplayName(User currentUser) {
        if (isPrivate) {
            for (User user : participants) {
                if (!user.getEmail().equals(currentUser.getEmail())) {
                    return user.getUserName();
                }
            }
            return "Private Chat";
        } else {
            if (groupName != null) {
                return groupName;
            }
            return "Event Group";
        }
    }

    public boolean isPrivate() {
        return this.isPrivate;
    }

    public String getChatId() {
        return this.chatId;
    }

    public void setChatId(String id) {
        this.chatId = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<Message> getMessages() {
        return this.messages;
    }

    public List<User> getParticipants() {
        return this.participants;
    }
}