import java.util.List;
import java.util.ArrayList;

public class ChatManager {

    private static ChatManager instance;
    private DataManager dataManager = new DataManager();
    private List<Chat> allChats;

    private ChatManager() {
        this.allChats = new ArrayList<>();
    }

    public static ChatManager getInstance() {
        if (instance == null) {
            instance = new ChatManager();
        }
        return instance;
    }

    public Chat createPrivateChat(User user1, User user2) {
        Chat newChat = new Chat(true);
        newChat.addParticipants(user1);
        newChat.addParticipants(user2);
        allChats.add(newChat);
        return newChat;
    }

    public Chat createGroupChat(List<User> eventParticipants) {
        Chat newChat = new Chat(false);
        if (eventParticipants != null) {
            for (User user : eventParticipants) {
                newChat.addParticipants(user);
            }
        }
        allChats.add(newChat);
        return newChat;
    }

    public void sendMessage(Chat chat, String content, User sender) {
        if (chat == null || sender == null)
            return;

        boolean isParticipant = false;
        for (User participant : chat.getParticipants()) {
            if (participant.getEmail().equals(sender.getEmail())) {
                isParticipant = true;
                break;
            }
        }

        if (isParticipant) {
            Message newMessage = new Message(content, sender);
            chat.addMessage(newMessage);
            dataManager.saveMessage(chat, newMessage);
        }
    }

    public Chat findGroupChatByName(String eventName) {
        for (Chat chat : allChats) {
            if (!chat.isPrivate() && chat.getGroupName() != null && chat.getGroupName().equals(eventName)) {
                return chat;
            }
        }
        return null;
    }

    public void setAllChats(List<Chat> chats) {
        this.allChats = chats;
    }
}