import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class EventController {

    public static boolean isCurrentEventsPage = false;

    @FXML
    private VBox eventListContainer;
    @FXML
    private TextField eventNameInput, locationInput, startHourInput, startMinInput, endHourInput, endMinInput,
            quotaInput;
    @FXML
    private Label errorLabel;
    @FXML
    private Circle sidebarProfileCircle;
    @FXML
    private Button profileNameButton;
    @FXML
    private FlowPane tagsFlowPane;
    @FXML
    private FlowPane filterFlowPane;

    private static EventController instance;

    public static final String[] UNIFIED_TAGS = {
            "Sports", "Gym & Fitness", "Study & Co-working", "Video Games", "Board Games",
            "Coffee & Chat", "Movies & Cinema", "Coding & Tech", "Music & Jamming", "Art & Creative",
            "Language Practice", "Dining Out", "Campus Walks", "Photography", "Books & Reading",
            "Volunteering", "Networking", "Anime & Manga", "Science & Math", "Shopping"
    };

    @FXML
    public void initialize() {
        instance = this;

        User me = SessionManager.getCurrentUser();
        if (me != null) {
            if (profileNameButton != null)
                profileNameButton.setText(me.getName() + " " + me.getSurname());
            if (sidebarProfileCircle != null) {
                String hex = me.getAvatarColor();
                if (hex != null && !hex.isEmpty()) {
                    try {
                        sidebarProfileCircle.setFill(Color.web(hex));
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        if (tagsFlowPane != null) {
            tagsFlowPane.getChildren().clear();
            for (String tag : UNIFIED_TAGS) {
                CheckBox cb = new CheckBox(tag);
                cb.setStyle("-fx-cursor: hand; -fx-text-fill: #333333;");
                tagsFlowPane.getChildren().add(cb);
            }
        }

        if (filterFlowPane != null) {
            filterFlowPane.getChildren().clear();

            Button allBtn = new Button("ALL");
            allBtn.setStyle(
                    "-fx-background-color: #FFFACD; -fx-background-radius: 14; -fx-border-color: #cccc88; -fx-border-radius: 14; -fx-cursor: hand;");
            allBtn.setOnAction(e -> loadEvents());
            filterFlowPane.getChildren().add(allBtn);

            for (String tag : UNIFIED_TAGS) {
                Button btn = new Button(tag.toUpperCase());
                btn.setStyle(
                        "-fx-background-color: #FFFACD; -fx-background-radius: 14; -fx-border-color: #cccc88; -fx-border-radius: 14; -fx-cursor: hand;");
                btn.setOnAction(this::handleFilterByTag);
                filterFlowPane.getChildren().add(btn);
            }
        }

        if (eventListContainer != null) {
            eventListContainer.getChildren().clear();
        }

        new Thread(() -> {
            DataManager dataManager = new DataManager();
            List<HangoutRequest> fetchedEvents = dataManager.getAllEventsFromFirebase();
            EventManager.getInstance().setEvents(fetchedEvents);

            Platform.runLater(this::loadEvents);
        }).start();
    }

    public static EventController getInstance() {
        return instance;
    }

    @FXML
    public void loadEvents() {
        if (eventListContainer == null)
            return;
        eventListContainer.getChildren().clear();

        User me = SessionManager.getCurrentUser();
        if (me == null)
            return;

        Schedule mySchedule = me.getSchedule();
        List<HangoutRequest> recommended = EventManager.getInstance().getRecommendedEvents(me);
        List<HangoutRequest> expired = new ArrayList<>();
        DataManager dm = new DataManager();

        recommended.sort((e1, e2) -> {
            int score1 = calculateEventScore(e1, me);
            int score2 = calculateEventScore(e2, me);
            return Integer.compare(score2, score1);
        });

        try {
            for (HangoutRequest request : recommended) {
                if (request.isExpired()) {
                    expired.add(request);
                    dm.deleteExpiredEventData(request.getName());
                    continue;
                }

                int dayIdx = request.getDay() - 1;
                if (mySchedule != null
                        && !mySchedule.isAvailableForEvent(dayIdx, request.getStartHour(), request.getEndHour()))
                    continue;

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/event.fxml"));
                Node card = loader.load();
                ((EventCardController) loader.getController()).setData(request);
                eventListContainer.getChildren().add(card);
            }
            if (!expired.isEmpty())
                EventManager.getInstance().getAllEvents().removeAll(expired);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void replaceCardWithDetails(Node oldCard, HangoutRequest request) {
        try {
            int idx = eventListContainer.getChildren().indexOf(oldCard);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/eventDetails.fxml"));
            Node detailNode = loader.load();
            ((EventDetailsController) loader.getController()).loadDetailedData(request);
            eventListContainer.getChildren().set(idx, detailNode);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleFilterByTag(ActionEvent e) {
        String clickedTag = ((Button) e.getSource()).getText().trim();
        if (eventListContainer == null)
            return;
        eventListContainer.getChildren().clear();

        User me = SessionManager.getCurrentUser();
        List<HangoutRequest> filtered = EventManager.getInstance().handleFilterByTag(clickedTag);

        filtered.sort((e1, e2) -> {
            int score1 = calculateEventScore(e1, me);
            int score2 = calculateEventScore(e2, me);
            return Integer.compare(score2, score1);
        });

        renderList(filtered);
    }

    @FXML
    public void handleCreateEvent(ActionEvent e) {
        try {
            List<String> tags = new ArrayList<>();
            if (tagsFlowPane != null) {
                for (Node node : tagsFlowPane.getChildren()) {
                    if (node instanceof CheckBox) {
                        CheckBox cb = (CheckBox) node;
                        if (cb.isSelected()) {
                            tags.add(cb.getText());
                        }
                    }
                }
            }

            User currentUser = SessionManager.getCurrentUser();
            if (currentUser == null) {
                setError("No logged-in user found.");
                return;
            }

            List<User> initialParticipants = new ArrayList<>();
            initialParticipants.add(currentUser);

            HangoutRequest newEvent = new HangoutRequest(
                    eventNameInput.getText().trim(),
                    locationInput.getText().trim(),
                    Integer.parseInt(startHourInput.getText().trim()),
                    Integer.parseInt(startMinInput.getText().trim()),
                    Integer.parseInt(endHourInput.getText().trim()),
                    Integer.parseInt(endMinInput.getText().trim()),
                    tags,
                    initialParticipants,
                    Integer.parseInt(quotaInput.getText().trim()),
                    currentUser);

            int currentDay = java.time.LocalDate.now().getDayOfWeek().getValue();
            newEvent.setDay(currentDay);

            DataManager dm = new DataManager();
            if (!dm.createEvent(newEvent)) {
                setError("Failed to save event.");
                return;
            }

            dm.getOrCreateGroupChat(newEvent.getName(), initialParticipants);

            EventManager.getInstance().addEvent(newEvent);
            currentUser.addOrganizedEvent(newEvent);
            setError("");

            goToMenu(e);

        } catch (Exception ex) {
            setError("Please check all fields are filled correctly.");
        }
    }

    public void handleJoinEvent(HangoutRequest event, User user) {
        if (event != null && user != null) {
            EventManager.getInstance().handleJoinEvent(event, user);
        }
    }

    @FXML
    public void goToProfile(ActionEvent e) throws IOException {
        navigate(e, "/myProfileUneditable.fxml");
    }

    @FXML
    public void goToMenu(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent e) throws IOException {
        navigate(e, "/searchView.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void openFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void openSchedule(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void openChat(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
            Parent root = loader.load();
            ChatController ctrl = loader.getController();
            if (ctrl != null)
                ctrl.setManagers(ChatManager.getInstance());

            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private int calculateEventScore(HangoutRequest event, User me) {
        if (me.getInterests() == null || event.getTags() == null)
            return 0;
        int score = 0;
        for (String tag : event.getTags()) {
            for (String interest : me.getInterests()) {
                if (tag.equalsIgnoreCase(interest))
                    score++;
            }
        }
        return score;
    }

    private void renderList(List<HangoutRequest> list) {
        try {
            for (HangoutRequest req : list) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/event.fxml"));
                Node card = loader.load();
                ((EventCardController) loader.getController()).setData(req);
                eventListContainer.getChildren().add(card);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void setError(String msg) {
        if (errorLabel != null)
            errorLabel.setText(msg);
        else
            System.out.println(msg);
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}