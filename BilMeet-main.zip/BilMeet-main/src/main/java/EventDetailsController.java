import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class EventDetailsController {

    @FXML
    private Text eventNameLabel;
    @FXML
    private Text timeLabel;
    @FXML
    private Text locationLabel;
    @FXML
    private HBox tagsBox;
    @FXML
    private Label tagsLabel;
    @FXML
    private Circle organiserCircle;
    @FXML
    private Label organiserNameLabel;
    @FXML
    private Text organiserNameText;
    @FXML
    private Button joinEventButton;
    @FXML
    private Button ignoreButton;

    private HangoutRequest currentEvent;

    public void loadDetailedData(HangoutRequest req) {
        this.currentEvent = req;

        if (eventNameLabel != null)
            eventNameLabel.setText(req.getName().toUpperCase());
        if (timeLabel != null)
            timeLabel.setText(req.getStartTime() + " - " + req.getEndTime());
        if (locationLabel != null)
            locationLabel.setText(req.getLocation());

        if (tagsBox != null) {
            tagsBox.getChildren().clear();

            if (req.getTags() != null && !req.getTags().isEmpty()) {
                for (String tag : req.getTags()) {
                    Label pill = new Label(tag.toUpperCase());
                    pill.setStyle(
                            "-fx-background-color: #FFFACD; " +
                                    "-fx-border-color: #cccc88; " +
                                    "-fx-background-radius: 15; " +
                                    "-fx-border-radius: 15; " +
                                    "-fx-padding: 4 12; " +
                                    "-fx-text-fill: #555555; " +
                                    "-fx-font-weight: bold; " +
                                    "-fx-font-size: 11px;");
                    tagsBox.getChildren().add(pill);
                }
            }
        }

        if (req.getOrganiser() != null) {
            String orgName = req.getOrganiser().getName() + " " + req.getOrganiser().getSurname();

            if (organiserNameLabel != null)
                organiserNameLabel.setText(orgName);
            if (organiserNameText != null)
                organiserNameText.setText(orgName);

            if (organiserCircle != null) {
                String hex = req.getOrganiser().getAvatarColor();
                if (hex != null && !hex.isEmpty()) {
                    try {
                        organiserCircle.setFill(javafx.scene.paint.Color.web(hex));
                    } catch (Exception e) {
                        organiserCircle.setFill(javafx.scene.paint.Color.LIGHTGRAY);
                    }
                }
            }
        }

        User me = SessionManager.getCurrentUser();
        if (req.getOrganiser() != null &&
                req.getOrganiser().getEmail().equals(me.getEmail())) {
            setupAsOrganizer();
        } else {
            setupAsParticipant(me);
        }
    }

    @FXML
    public void handleJoinEvent(ActionEvent e) {
        User me = SessionManager.getCurrentUser();

        if (currentEvent.getOrganiser() != null &&
                currentEvent.getOrganiser().getEmail().equals(me.getEmail())) {

            DataManager dm = new DataManager();
            dm.deleteExpiredEventData(currentEvent.getName());

            EventManager.getInstance().getAllEvents().remove(currentEvent);
            EventController.getInstance().loadEvents();
            return;
        }

        EventManager.getInstance().handleJoinEvent(currentEvent, me);
        setupAsParticipant(me);
    }

    @FXML
    public void handleBack(ActionEvent e) {
        if (EventController.isCurrentEventsPage) {
            CurrentEventsController.getInstance().loadEvents();
        } else {
            EventController.getInstance().loadEvents();
        }
    }

    @FXML
    public void handleShowOrganiserProfile(javafx.scene.input.MouseEvent event) {
        try {
            User me = SessionManager.getCurrentUser();
            User organizer = currentEvent.getOrganiser();
            String fxml;
            boolean isFriend = false;

            if (me != null && me.getFriends() != null) {
                for (Object item : me.getFriends()) {
                    if (item instanceof String) {
                        if (((String) item).equals(organizer.getEmail()))
                            isFriend = true;
                    } else if (item instanceof User) {
                        if (((User) item).getEmail().equals(organizer.getEmail()))
                            isFriend = true;
                    }
                }
            }

            if (me != null && me.getEmail().equals(organizer.getEmail())) {
                fxml = "/myProfileUneditable.fxml";
            } else if (isFriend) {
                fxml = "/friendProfileView.fxml";
            } else {
                fxml = "/strangerProfile-sendRequest.fxml";
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            Object controller = loader.getController();
            if (controller instanceof StrangerProfileController) {
                StrangerProfileController spc = (StrangerProfileController) controller;
                spc.setUser(organizer);
                spc.setPreviousPage("/AvailableEvents.fxml");
            }

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupAsParticipant(User me) {
        boolean isAlreadyJoined = false;
        if (currentEvent.getParticipants() != null) {
            for (User participant : currentEvent.getParticipants()) {
                if (participant.getEmail().equals(me.getEmail())) {
                    isAlreadyJoined = true;
                    break;
                }
            }
        }

        if (isAlreadyJoined) {
            joinEventButton.setText("ALREADY JOINED");
            joinEventButton.setDisable(true);
        } else if (currentEvent.isFull()) {
            joinEventButton.setText("FULL");
            joinEventButton.setDisable(true);
        } else {
            joinEventButton.setText("Join Event");
            joinEventButton.setDisable(false);
        }
    }

    private void setupAsOrganizer() {
        joinEventButton.setText("DELETE");
        if (ignoreButton != null)
            ignoreButton.setVisible(false);
    }
}