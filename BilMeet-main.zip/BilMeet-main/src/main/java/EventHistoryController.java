import java.io.IOException;
import java.util.List;
import java.util.Map;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EventHistoryController {

    @FXML
    private VBox historyListContainer;

    public void initialize() {
        User me = SessionManager.getCurrentUser();

        new Thread(() -> {
            DataManager dm = new DataManager();
            List<Map<String, Object>> pastEvents = dm.getPastEvents(me.getEmail());

            Platform.runLater(() -> {
                if (historyListContainer == null)
                    return;
                historyListContainer.getChildren().clear();

                if (pastEvents.isEmpty()) {
                    Label empty = new Label("No past events found.");
                    empty.setStyle("-fx-font-size: 16px; -fx-text-fill: #555;");
                    historyListContainer.getChildren().add(empty);
                    return;
                }

                int limit = Math.min(3, pastEvents.size());

                for (int i = 0; i < limit; i++) {
                    Map<String, Object> data = pastEvents.get(i);

                    VBox card = new VBox(5);
                    card.setStyle(
                            "-fx-background-color: #FFFACD; -fx-padding: 15; -fx-background-radius: 15; -fx-border-color: #cccc88; -fx-border-radius: 15;");

                    Label name = new Label(((String) data.get("name")).toUpperCase());
                    name.setStyle("-fx-font-weight: bold; -fx-font-size: 18px; -fx-text-fill: #333333;");

                    Label loc = new Label("Location: " + data.get("location"));
                    loc.setStyle("-fx-font-size: 14px; -fx-text-fill: #555555;");

                    String formattedTime = String.format("Time: %d:%02d - %d:%02d",
                            ((Number) data.get("startHour")).intValue(), ((Number) data.get("startMin")).intValue(),
                            ((Number) data.get("endHour")).intValue(), ((Number) data.get("endMin")).intValue());

                    Label time = new Label(formattedTime);
                    time.setStyle("-fx-font-size: 14px; -fx-text-fill: #555555;");

                    card.getChildren().addAll(name, loc, time);
                    historyListContainer.getChildren().add(card);
                }
            });
        }).start();
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/myProfileUneditable.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}