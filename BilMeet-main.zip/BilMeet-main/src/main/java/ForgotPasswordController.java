import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.application.Platform;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.cloud.FirestoreClient;

public class ForgotPasswordController {

    @FXML
    private TextField mailField;
    @FXML
    private TextField codeField;
    @FXML
    private Label statusLabel;

    @FXML
    private void handleSendCode(ActionEvent event) {
        String email = mailField.getText().trim().toLowerCase();

        if (email.isEmpty()) {
            statusLabel.setText("Please enter your e-mail.");
            return;
        }

        if (!email.endsWith("@ug.bilkent.edu.tr")) {
            statusLabel.setText("Please use your Bilkent e-mail.");
            return;
        }

        statusLabel.setText("Sending code, please wait...");

        new Thread(() -> {
            try {
                String code = PasswordResetManager.generateCode();
                PasswordResetManager.saveCodeToFirebase(email, code);
                PasswordResetManager.sendCodeEmail(email, code);

                Platform.runLater(() -> {
                    statusLabel.setText("Code sent. Check your e-mail.");
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    statusLabel.setText("Failed to send code.");
                });
            }
        }).start();
    }

    @FXML
    private void handleVerifyCode(ActionEvent event) {
        String email = mailField.getText().trim().toLowerCase();
        String enteredCode = codeField.getText().trim();

        if (email.isEmpty()) {
            statusLabel.setText("Please enter your e-mail.");
            return;
        }

        if (enteredCode.isEmpty()) {
            statusLabel.setText("Please enter the code.");
            return;
        }

        statusLabel.setText("Verifying...");
        String safeEmail = email.replace(".", ",");

        DatabaseReference resetRef = FirebaseDatabase
                .getInstance("https://bilmeet-30953-default-rtdb.firebaseio.com/")
                .getReference("passwordResetCodes")
                .child(safeEmail);

        resetRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    Platform.runLater(() -> statusLabel.setText("No reset code found."));
                    return;
                }

                Object codeObject = snapshot.child("code").getValue();
                Object expiresObject = snapshot.child("expiresAt").getValue();

                if (codeObject == null || expiresObject == null) {
                    Platform.runLater(() -> statusLabel.setText("Reset code data is incomplete."));
                    return;
                }

                String savedCode = String.valueOf(codeObject);
                long expiresAt = Long.parseLong(String.valueOf(expiresObject));

                if (System.currentTimeMillis() > expiresAt) {
                    Platform.runLater(() -> statusLabel.setText("Code expired."));
                    return;
                }

                if (!enteredCode.equals(savedCode)) {
                    Platform.runLater(() -> statusLabel.setText("Wrong code."));
                    return;
                }

                Platform.runLater(() -> statusLabel.setText("Code verified! Updating password..."));

                updateUserPassword(email, savedCode, resetRef, event);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Platform.runLater(() -> statusLabel.setText("Database error while verifying."));
            }
        });
    }

    @FXML
    private void goBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/LoginNew.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void updateUserPassword(String email, String newPassword, DatabaseReference resetRef, ActionEvent event) {
        new Thread(() -> {
            try {
                Firestore db = FirestoreClient.getFirestore();
                ApiFuture<QuerySnapshot> future = db.collection("users")
                        .whereEqualTo("userMail", email)
                        .get();

                QuerySnapshot querySnapshot = future.get();

                if (querySnapshot.isEmpty()) {
                    Platform.runLater(() -> statusLabel.setText("User not found."));
                    return;
                }

                for (QueryDocumentSnapshot document : querySnapshot) {
                    db.collection("users")
                            .document(document.getId())
                            .update("userPassword", newPassword).get();

                    resetRef.removeValueAsync();

                    Platform.runLater(() -> {
                        statusLabel.setText("Password updated successfully!");
                        try {
                            goBackToLogin(event);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                    break;
                }

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> statusLabel.setText("Failed to update password."));
            }
        }).start();
    }
}