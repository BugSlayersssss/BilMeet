import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FriendCardController {

    @FXML
    private Text friendFirstNameText;
    @FXML
    private Text friendLastNameText;
    @FXML
    private Text friendAccountIdText;
    @FXML
    private Text friendNameText;
    @FXML
    private Circle avatarCircle;

    @FXML
    private Label requestNameLabel;
    @FXML
    private Label requestEmailLabel;
    @FXML
    private Circle requestAvatarCircle;
    @FXML
    private Button acceptButton;
    @FXML
    private Button rejectButton;

    private String previousPage = "/friendView.fxml";
    private User cardUser;
    private FriendRequest cardRequest;

    public void setPreviousPage(String fxmlPath) {
        this.previousPage = fxmlPath;
    }

    public void setData(User user) {
        this.cardUser = user;

        if (friendFirstNameText != null)
            friendFirstNameText.setText(user.getName());
        if (friendLastNameText != null)
            friendLastNameText.setText(user.getSurname());
        if (friendAccountIdText != null)
            friendAccountIdText.setText("Account ID:" + user.getId());

        if (avatarCircle != null) {
            String hex = user.getAvatarColor();
            if (hex != null && !hex.isEmpty()) {
                try {
                    avatarCircle.setFill(Color.web(hex));
                } catch (Exception ignored) {
                }
            }
        }

        if (friendNameText != null)
            friendNameText.setText(user.getUserName());
    }

    public void setRequestData(FriendRequest request) {
        this.cardRequest = request;
        User sender = request.getSender();

        if (requestNameLabel != null)
            requestNameLabel.setText(sender.getName() + " " + sender.getSurname());
        if (requestEmailLabel != null)
            requestEmailLabel.setText(sender.getEmail());

        if (requestAvatarCircle != null) {
            String hex = sender.getAvatarColor();
            if (hex != null && !hex.isEmpty()) {
                try {
                    requestAvatarCircle.setFill(Color.web(hex));
                } catch (Exception ignored) {
                }
            }
        }
    }

    @FXML
    public void openFriendProfile(MouseEvent event) {
        if (cardUser == null)
            return;
        try {
            User me = SessionManager.getCurrentUser();
            String fxml;
            boolean isFriend = false;

            if (me != null && me.getFriends() != null) {
                for (Object item : me.getFriends()) {
                    if (item instanceof String) {
                        if (((String) item).equals(cardUser.getEmail()))
                            isFriend = true;
                    } else if (item instanceof User) {
                        if (((User) item).getEmail().equals(cardUser.getEmail()))
                            isFriend = true;
                    }
                }
            }

            if (me != null && me.getEmail().equals(cardUser.getEmail())) {
                fxml = "/myProfileUneditable.fxml";
            } else if (isFriend) {
                fxml = "/friendProfileView.fxml";
            } else {
                fxml = "/strangerProfile-sendRequest.fxml";
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            Object controller = loader.getController();
            if (controller instanceof StrangerProfileController) {
                StrangerProfileController spc = (StrangerProfileController) controller;
                spc.setUser(cardUser);
                spc.setPreviousPage(this.previousPage);
            }

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleAccept(javafx.event.ActionEvent event) {
        if (cardRequest == null)
            return;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/friendView.fxml"));
            Parent root = loader.load();
            FriendController ctrl = loader.getController();
            ctrl.acceptFriendRequest(cardRequest);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleReject(javafx.event.ActionEvent event) {
        if (cardRequest == null)
            return;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/friendView.fxml"));
            Parent root = loader.load();
            FriendController ctrl = loader.getController();
            ctrl.rejectFriendRequest(cardRequest);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}