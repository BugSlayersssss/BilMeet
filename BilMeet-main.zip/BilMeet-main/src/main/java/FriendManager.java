import java.util.List;

public class FriendManager {

    private final DataManager dataManager = new DataManager();

    public List<FriendRequest> getPendingRequests(User user) {
        if (user == null)
            return java.util.Collections.emptyList();
        return dataManager.getPendingFriendRequests(user.getEmail());
    }

    public void acceptRequest(FriendRequest request, User receiver) {
        if (request == null || receiver == null)
            return;

        boolean updated = dataManager.updateFriendRequestStatus(
                request.getSender().getEmail(),
                receiver.getEmail(),
                "accepted");

        if (updated) {
            dataManager.addFriendToBothUsers(
                    request.getSender().getEmail(),
                    receiver.getEmail());

            dataManager.getOrCreatePrivateChat(request.getSender(), receiver);

            request.accept();
        }
    }

    public void rejectRequest(FriendRequest request, User receiver) {
        if (request == null || receiver == null)
            return;

        boolean updated = dataManager.updateFriendRequestStatus(
                request.getSender().getEmail(),
                receiver.getEmail(),
                "rejected");

        if (updated) {
            request.reject();
        }
    }
}