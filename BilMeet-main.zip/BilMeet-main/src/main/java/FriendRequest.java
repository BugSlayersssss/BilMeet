public class FriendRequest {

    private String status;
    private User senderr;

    public FriendRequest(User sender) {
        this.status = "awaiting";
        this.senderr = sender;
    }

    public void accept() {
        this.status = "accepted";
    }

    public void reject() {
        this.status = "rejected";
    }

    public String getStatus() {
        return this.status;
    }

    public User getSender() {
        return this.senderr;
    }
}