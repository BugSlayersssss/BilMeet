import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

    @FXML
    private TextField mailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label wrongPasswordLabel;

    private Stage stage;
    private Scene scene;
    private Parent root;
    private DataManager dataManager = new DataManager();

    @FXML
    private void handleLogin(ActionEvent event) {
        String mail = mailField.getText().trim();
        String password = passwordField.getText().trim();

        wrongPasswordLabel.setVisible(false);

        new Thread(() -> {
            User loggedInUser = dataManager.authenticateAndGetUser(mail, password);

            Platform.runLater(() -> {
                if (loggedInUser != null) {
                    SessionManager.setCurrentUser(loggedInUser);
                    try {
                        openProfile(event);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    wrongPasswordLabel.setText("Wrong Email or Password!");
                    wrongPasswordLabel.setVisible(true);
                }
            });
        }).start();
    }

    @FXML
    public void openProfile(ActionEvent e) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/myProfileUneditable.fxml"));
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void goToForgotPassword(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/ForgotPassword.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void goToSignUp(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/SignUp.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}