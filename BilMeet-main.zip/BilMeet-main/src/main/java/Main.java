import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FirebaseInitializer.initialize();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/LoginNew.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
        stage.setFullScreen(false);
        stage.setTitle("BilMeet");
        stage.show();
    }

    public static void main(String[] args) {
        FirebaseInitializer.initialize();
        launch(args);
    }
}