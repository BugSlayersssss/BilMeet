import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.VBox;

public class OrganizedEventsController {

    @FXML
    private VBox organizedContainer;

    public void loadOrganizedEvents() {
        organizedContainer.getChildren().clear();
        User me = SessionManager.getCurrentUser();

        if (me == null)
            return;

        List<HangoutRequest> myEvents = me.getOrganizedEvents();

        try {
            for (HangoutRequest event : myEvents) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/event.fxml"));
                Node card = loader.load();

                EventCardController controller = loader.getController();
                controller.setData(event);

                organizedContainer.getChildren().add(card);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}