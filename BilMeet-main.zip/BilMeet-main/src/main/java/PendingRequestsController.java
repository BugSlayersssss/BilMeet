import java.io.IOException;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class PendingRequestsController {

    @FXML
    private VBox requestsContainer;
    @FXML
    private Label statusLabel;
    @FXML
    private Button profileNameButton;

    private final FriendManager friendManager = new FriendManager();

    @FXML
    public void initialize() {
        User currentUser = SessionManager.getCurrentUser();
        if (currentUser != null) {
            loadPendingRequests(currentUser);
            if (profileNameButton != null) {
                profileNameButton.setText(currentUser.getName() + " " + currentUser.getSurname());
            }
        }
    }

    public void loadPendingRequests(User user) {
        if (requestsContainer != null) {
            requestsContainer.getChildren().clear();
        }

        new Thread(() -> {
            List<FriendRequest> requests = friendManager.getPendingRequests(user);

            Platform.runLater(() -> {
                if (requests.isEmpty()) {
                    Label emptyLabel = new Label("No pending friend requests.");
                    emptyLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
                    if (requestsContainer != null) {
                        requestsContainer.getChildren().add(emptyLabel);
                    }
                    return;
                }

                for (FriendRequest request : requests) {
                    User sender = request.getSender();
                    HBox row = createRequestRow(sender, request, user);
                    if (requestsContainer != null) {
                        requestsContainer.getChildren().add(row);
                    }
                }
            });
        }).start();
    }

    @FXML
    public void goBackToFriends(ActionEvent event) throws IOException {
        navigate(event, "/friendView.fxml");
    }

    @FXML
    public void goToMenu(ActionEvent event) throws IOException {
        navigate(event, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToChat(ActionEvent event) throws IOException {
        navigate(event, "/Chat.fxml");
    }

    @FXML
    public void goToSchedule(ActionEvent event) throws IOException {
        navigate(event, "/Schedule.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent event) throws IOException {
        navigate(event, "/createEvent.fxml");
    }

    @FXML
    public void goToFriends(ActionEvent event) throws IOException {
        navigate(event, "/friendView.fxml");
    }

    @FXML
    public void goToProfile(ActionEvent event) throws IOException {
        navigate(event, "/myProfileUneditable.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent event) throws IOException {
        navigate(event, "/searchView.fxml");
    }

    private HBox createRequestRow(User sender, FriendRequest request, User receiver) {
        HBox row = new HBox();
        row.setSpacing(18);
        row.setAlignment(Pos.CENTER_LEFT);

        StackPane profilePane = new StackPane();
        profilePane.setPrefSize(95, 95);
        profilePane.setStyle("-fx-cursor: hand;");

        Circle outerCircle = new Circle(46);
        outerCircle.setFill(Color.web(sender.getAvatarColor() != null ? sender.getAvatarColor() : "#F5EFD8"));
        outerCircle.setStroke(Color.BLACK);
        outerCircle.setStrokeWidth(3);

        Label profileIcon = new Label("👤");
        profileIcon.setStyle("-fx-font-size: 42px;");

        profilePane.getChildren().addAll(outerCircle, profileIcon);

        profilePane.setOnMouseClicked(e -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/strangerProfile-accept-reject.fxml"));
                Parent root = loader.load();
                StrangerProfileController ctrl = loader.getController();
                ctrl.setUser(sender);

                Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        HBox card = new HBox();
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPrefHeight(78);
        card.setPrefWidth(420);
        card.setSpacing(18);
        card.setStyle("-fx-background-color: #3FC8D1; -fx-background-radius: 20; -fx-padding: 0 16 0 20;");

        VBox nameBox = new VBox();
        nameBox.setAlignment(Pos.CENTER_LEFT);
        nameBox.setSpacing(2);
        nameBox.setPrefWidth(150);

        Label nameLabel = new Label(sender.getName());
        nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 17px; -fx-font-weight: bold;");

        Label surnameLabel = new Label(sender.getSurname());
        surnameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 17px; -fx-font-weight: bold;");

        nameBox.getChildren().addAll(nameLabel, surnameLabel);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button acceptButton = new Button("✓");
        acceptButton.setPrefSize(64, 64);
        acceptButton.setStyle(
                "-fx-background-color: #95D84B; -fx-background-radius: 100; -fx-text-fill: #7B44D6; -fx-font-size: 28px; -fx-font-weight: bold; -fx-cursor: hand;");

        Button rejectButton = new Button("✕");
        rejectButton.setPrefSize(64, 64);
        rejectButton.setStyle(
                "-fx-background-color: #FF7F87; -fx-background-radius: 100; -fx-text-fill: #5A63D8; -fx-font-size: 24px; -fx-font-weight: bold; -fx-cursor: hand;");

        acceptButton.setOnAction(e -> {
            friendManager.acceptRequest(request, receiver);
            setStatus("Friend request accepted.");
            loadPendingRequests(receiver);
        });

        rejectButton.setOnAction(e -> {
            friendManager.rejectRequest(request, receiver);
            setStatus("Friend request rejected.");
            loadPendingRequests(receiver);
        });

        card.getChildren().addAll(nameBox, spacer, acceptButton, rejectButton);
        row.getChildren().addAll(profilePane, card);

        return row;
    }

    private void setStatus(String text) {
        if (statusLabel != null) {
            statusLabel.setText(text);
        }
    }

    private void navigate(ActionEvent event, String fxmlPath) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}