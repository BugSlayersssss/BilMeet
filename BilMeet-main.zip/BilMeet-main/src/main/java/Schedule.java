public class Schedule {

    private boolean[][] availabilityMatrix;

    public Schedule() {
        this.availabilityMatrix = new boolean[7][24];
    }

    public void setAvailability(int day, int hour, boolean isFree) {
        if (isValidSlot(day, hour)) {
            availabilityMatrix[day][hour] = isFree;
        }
    }

    public boolean isAvailableForEvent(int dayIndex, int startHour, int endHour) {
        if (dayIndex < 0 || dayIndex > 6)
            return false;
        for (int i = startHour; i < endHour; i++) {
            if (availabilityMatrix[dayIndex][i])
                return false;
        }
        return true;
    }

    public boolean[][] getBusySlots() {
        return availabilityMatrix;
    }

    public void setBusySlots(boolean[][] slots) {
        if (slots == null)
            return;
        for (int d = 0; d < Math.min(7, slots.length); d++) {
            for (int h = 0; h < Math.min(24, slots[d].length); h++) {
                availabilityMatrix[d][h] = slots[d][h];
            }
        }
    }

    private boolean isValidSlot(int day, int hour) {
        return day >= 0 && day < 7 && hour >= 0 && hour < 24;
    }
}