import java.io.IOException;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class SearchController {

    @FXML
    private FlowPane searchContainer;
    @FXML
    private TextField searchNameField;
    @FXML
    private Label statusLabel;
    @FXML
    private Label pageTitleLabel;

    @FXML
    private Circle profileCircle;
    @FXML
    private Button profileNameButton;
    @FXML
    private Button pendingRequestsBadge;

    @FXML
    public void initialize() {
        User me = SessionManager.getCurrentUser();
        if (me == null)
            return;

        if (profileNameButton != null)
            profileNameButton.setText(me.getName() + " " + me.getSurname());
        if (profileCircle != null && me.getAvatarColor() != null) {
            try {
                profileCircle.setFill(Color.web(me.getAvatarColor()));
            } catch (Exception ignored) {
            }
        }

        DataManager dm = new DataManager();

        new Thread(() -> {
            int pendingCount = dm.getPendingFriendRequests(me.getEmail()).size();
            Platform.runLater(() -> {
                if (pendingRequestsBadge != null) {
                    pendingRequestsBadge.setText(String.valueOf(pendingCount));
                }
            });
        }).start();

        loadTopMatches(me, dm);
    }

    @FXML
    public void handleSearchByName(ActionEvent e) {
        String query = searchNameField.getText().trim();
        User me = SessionManager.getCurrentUser();
        DataManager dm = new DataManager();

        if (query.isEmpty()) {
            loadTopMatches(me, dm);
            return;
        }

        if (pageTitleLabel != null)
            pageTitleLabel.setText("SEARCH RESULTS");
        searchContainer.getChildren().clear();

        new Thread(() -> {
            List<User> searchResults = dm.searchUsersByName(query);

            searchResults.sort((u1, u2) -> {
                int score1 = calculateInterestScore(u1, me);
                int score2 = calculateInterestScore(u2, me);
                return Integer.compare(score2, score1);
            });

            Platform.runLater(() -> {
                renderUsers(searchResults, me);
            });
        }).start();
    }

    @FXML
    public void goToProfile(ActionEvent e) throws IOException {
        navigate(e, "/myProfileUneditable.fxml");
    }

    @FXML
    public void goToMenu(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent e) throws IOException {
        navigate(e, "/searchView.fxml");
    }

    @FXML
    public void goToChat(ActionEvent e) throws IOException {
        navigate(e, "/Chat.fxml");
    }

    @FXML
    public void goToSchedule(ActionEvent e) throws IOException {
        navigate(e, "/Schedule.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void showPendingRequests(ActionEvent e) throws IOException {
        navigate(e, "/pendingRequestsView.fxml");
    }

    @FXML
    public void openSchedule(javafx.scene.input.MouseEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void loadTopMatches(User me, DataManager dm) {
        if (pageTitleLabel != null)
            pageTitleLabel.setText("LOADING TOP MATCHES...");
        searchContainer.getChildren().clear();

        new Thread(() -> {
            List<User> allUsers = dm.getAllUsers();
            MatchAlgorithm algorithm = new MatchAlgorithm();

            List<User> orderedUsers = algorithm.getOrderedList(me, allUsers);

            int limit = Math.min(10, orderedUsers.size());
            List<User> top10 = orderedUsers.subList(0, limit);

            Platform.runLater(() -> {
                if (pageTitleLabel != null)
                    pageTitleLabel.setText("TOP MATCHES");
                renderUsers(top10, me);
            });
        }).start();
    }

    private void renderUsers(List<User> usersToDisplay, User me) {
        try {
            for (User foundUser : usersToDisplay) {
                if (foundUser.getEmail().equals(me.getEmail()))
                    continue;

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/friendObject.fxml"));
                Node card = loader.load();

                FriendCardController ctrl = loader.getController();
                ctrl.setData(foundUser);
                ctrl.setPreviousPage("/searchView.fxml");

                searchContainer.getChildren().add(card);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private int calculateInterestScore(User otherUser, User me) {
        if (otherUser.getInterests() == null || me.getInterests() == null)
            return 0;
        int score = 0;
        for (String theirInterest : otherUser.getInterests()) {
            for (String myInterest : me.getInterests()) {
                if (theirInterest.equalsIgnoreCase(myInterest))
                    score++;
            }
        }
        return score;
    }
}