import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController {

    @FXML
    private TextField mailField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField surnameField;
    @FXML
    private TextField deptField;
    @FXML
    private PasswordField createPasswordField;
    @FXML
    private Label errorLabel;

    private final DataManager dataManager = new DataManager();

    @FXML
    private void handleSignUp(ActionEvent event) {
        String email = mailField.getText().trim();
        String name = nameField.getText().trim();
        String surname = surnameField.getText().trim();
        String department = deptField.getText().trim();
        String password = createPasswordField.getText().trim();

        if (email.isEmpty() || name.isEmpty() || surname.isEmpty()
                || department.isEmpty() || password.isEmpty()) {
            setError("Please fill all fields.");
            return;
        }

        if (!email.endsWith("@ug.bilkent.edu.tr")) {
            setError("Please use your Bilkent email (@ug.bilkent.edu.tr).");
            return;
        }

        setError("Creating account, please wait...");

        new Thread(() -> {
            boolean created = dataManager.createUser(name, surname, department, password, email);

            Platform.runLater(() -> {
                if (created) {
                    setError("Account created successfully!");
                    try {
                        goBackToLogin(event);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    setError("This email is already registered.");
                }
            });
        }).start();
    }

    @FXML
    private void goBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/LoginNew.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void setError(String msg) {
        if (errorLabel != null) {
            errorLabel.setText(msg);
        }
    }
}