import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class StrangerProfileController {

    @FXML
    private Circle avatarCircle;
    @FXML
    private Circle sidebarProfileCircle;
    @FXML
    private Button profileNameButton;
    @FXML
    private Label userNameLabel;
    @FXML
    private Label deptLabel;
    @FXML
    private Label accountIdLabel;
    @FXML
    private VBox interestsVBox;
    @FXML
    private Button sendRequestButton;
    @FXML
    private Button acceptButton;
    @FXML
    private Button rejectButton;
    @FXML
    private Label statusLabel;

    private String previousPage = "/friendView.fxml";
    private User viewedUser;

    public void setUser(User user) {
        this.viewedUser = user;

        User me = SessionManager.getCurrentUser();
        if (me != null) {
            if (profileNameButton != null) {
                profileNameButton.setText(me.getName() + " " + me.getSurname());
            }
            if (sidebarProfileCircle != null) {
                String hex = me.getAvatarColor();
                if (hex != null && !hex.isEmpty()) {
                    try {
                        sidebarProfileCircle.setFill(Color.web(hex));
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        if (userNameLabel != null)
            userNameLabel.setText(user.getName() + " " + user.getSurname());
        if (deptLabel != null)
            deptLabel.setText("Department: " + (user.getDepartment() != null ? user.getDepartment() : ""));
        if (accountIdLabel != null)
            accountIdLabel.setText("Account ID: " + user.getId());

        if (avatarCircle != null) {
            String hex = user.getAvatarColor();
            if (hex != null && !hex.isEmpty()) {
                try {
                    avatarCircle.setFill(Color.web(hex));
                } catch (Exception ignored) {
                }
            }
        }

        if (interestsVBox != null) {
            interestsVBox.getChildren().clear();
            if (user.getInterests() == null || user.getInterests().isEmpty()) {
                Label emptyLabel = new Label("No interests added yet.");
                emptyLabel.setStyle("-fx-text-fill: #888888; -fx-font-style: italic;");
                interestsVBox.getChildren().add(emptyLabel);
            } else {
                for (String interest : user.getInterests()) {
                    Label lbl = new Label("• " + interest);
                    lbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");
                    interestsVBox.getChildren().add(lbl);
                }
            }
        }

        if (sendRequestButton != null && me != null) {
            new Thread(() -> {
                DataManager dm = new DataManager();
                boolean alreadySent = dm.friendRequestAlreadyExists(me.getEmail(), user.getEmail());

                if (alreadySent) {
                    Platform.runLater(() -> {
                        sendRequestButton.setText("Request Sent");
                        sendRequestButton.setDisable(true);
                        sendRequestButton.setStyle(
                                "-fx-background-color: #AAAAAA; -fx-text-fill: white; -fx-background-radius: 20; -fx-cursor: default;");
                    });
                }
            }).start();
        }
    }

    public void setPreviousPage(String fxmlPath) {
        this.previousPage = fxmlPath;
    }

    @FXML
    public void handleSendFriendRequest(ActionEvent event) {
        User me = SessionManager.getCurrentUser();
        if (me == null || viewedUser == null) {
            setStatus("Error: user data missing.");
            return;
        }

        setStatus("Sending request...");
        if (sendRequestButton != null)
            sendRequestButton.setDisable(true);

        new Thread(() -> {
            DataManager dm = new DataManager();
            boolean alreadyExists = dm.friendRequestAlreadyExists(me.getEmail(), viewedUser.getEmail());

            if (alreadyExists) {
                Platform.runLater(() -> {
                    setStatus("Request already sent.");
                    if (sendRequestButton != null) {
                        sendRequestButton.setText("Request Sent");
                        sendRequestButton.setStyle(
                                "-fx-background-color: #AAAAAA; -fx-text-fill: white; -fx-background-radius: 20; -fx-cursor: default;");
                    }
                });
                return;
            }

            boolean success = dm.createFriendRequest(me, viewedUser);

            Platform.runLater(() -> {
                if (success) {
                    setStatus("Friend request sent!");
                    if (sendRequestButton != null) {
                        sendRequestButton.setText("Request Sent");
                        sendRequestButton.setStyle(
                                "-fx-background-color: #AAAAAA; -fx-text-fill: white; -fx-background-radius: 20; -fx-cursor: default;");
                    }
                } else {
                    setStatus("Could not send request.");
                    if (sendRequestButton != null)
                        sendRequestButton.setDisable(false);
                }
            });
        }).start();
    }

    @FXML
    public void handleAcceptRequest(ActionEvent event) {
        User me = SessionManager.getCurrentUser();
        if (me == null || viewedUser == null) {
            setStatus("Error: user data missing.");
            return;
        }

        setStatus("Accepting request...");
        if (acceptButton != null)
            acceptButton.setDisable(true);

        new Thread(() -> {
            DataManager dm = new DataManager();
            boolean success = dm.acceptFriendRequest(viewedUser.getEmail(), me.getEmail());

            if (success) {
                dm.getOrCreatePrivateChat(viewedUser, me);
                Platform.runLater(() -> {
                    setStatus("Friend request accepted.");
                    goToFriendsScreen(event);
                });
            } else {
                Platform.runLater(() -> {
                    setStatus("Could not accept request.");
                    if (acceptButton != null)
                        acceptButton.setDisable(false);
                });
            }
        }).start();
    }

    @FXML
    public void handleRejectRequest(ActionEvent event) {
        User me = SessionManager.getCurrentUser();
        if (me == null || viewedUser == null) {
            setStatus("Error: user data missing.");
            return;
        }

        setStatus("Rejecting request...");
        if (rejectButton != null)
            rejectButton.setDisable(true);

        new Thread(() -> {
            DataManager dm = new DataManager();
            boolean success = dm.rejectFriendRequest(viewedUser.getEmail(), me.getEmail());

            Platform.runLater(() -> {
                if (success) {
                    setStatus("Request rejected.");
                    goToFriendsScreen(event);
                } else {
                    setStatus("Could not reject request.");
                    if (rejectButton != null)
                        rejectButton.setDisable(false);
                }
            });
        }).start();
    }

    @FXML
    public void openChat(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
            Parent root = loader.load();

            ChatController ctrl = loader.getController();
            if (ctrl != null) {
                ctrl.setManagers(ChatManager.getInstance());
            }

            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    public void goToProfile(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToMenu(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent e) throws IOException {
        navigate(e, "/searchView.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void goToChat(ActionEvent e) throws IOException {
        navigate(e, "/Chat.fxml");
    }

    @FXML
    public void openEventHistory(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/EventHistory.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        navigate(e, previousPage);
    }

    @FXML
    public void openSchedule(MouseEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void goToFriendsScreen(ActionEvent event) {
        try {
            navigate(event, "/friendView.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setStatus(String msg) {
        if (statusLabel != null) {
            statusLabel.setText(msg);
        }
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}