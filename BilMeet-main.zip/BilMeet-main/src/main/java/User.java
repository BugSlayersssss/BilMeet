import java.util.ArrayList;
import java.util.List;

public class User {

    private String userId;
    private String name;
    private String surname;
    private String email;
    private String password;
    private String department;
    private String avatarColor = "#C8A0C8";

    private List<String> interests;
    private List<User> friends;
    private List<FriendRequest> friendRequests;
    private List<HangoutRequest> eventHistory;
    private List<HangoutRequest> organizedEvents;
    private Schedule schedule;

    public final int[] availableInterestCodes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    public final String[] availableInterestNames = {
            "Books", "Music", "Baking", "Volleyball", "Football", "Movies",
            "Comic Books", "Drawing", "Video Games", "Cat Person", "Dog Person",
            "Basketball", "Mentoring"
    };

    public User(String name, String surname, String email, String password, String department) {
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.password = password;
        this.department = department;

        this.interests = new ArrayList<>();
        this.friends = new ArrayList<>();
        this.friendRequests = new ArrayList<>();
        this.eventHistory = new ArrayList<>();
        this.organizedEvents = new ArrayList<>();
        this.schedule = new Schedule();
    }

    public void updateProfile(String newName, String newSurname, String newDept) {
        this.name = newName;
        this.surname = newSurname;
        this.department = newDept;
    }

    public void addOrganizedEvent(HangoutRequest event) {
        if (!organizedEvents.contains(event))
            organizedEvents.add(event);
    }

    public void addInterest(String interest) {
        if (!interests.contains(interest))
            interests.add(interest);
    }

    public void addFriend(User newFriend) {
        if (!friends.contains(newFriend))
            friends.add(newFriend);
    }

    public void addPendingRequest(FriendRequest fr) {
        friendRequests.add(fr);
    }

    public String getUserId() {
        return userId;
    }

    public String getId() {
        return (userId != null && !userId.isEmpty()) ? userId : (email != null ? email.split("@")[0] : "");
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getDepartment() {
        return department;
    }

    public String getUserName() {
        return name + " " + surname;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public List<String> getInterests() {
        return interests;
    }

    public List<User> getFriends() {
        return friends;
    }

    public String getUserPassword() {
        return password;
    }

    public List<HangoutRequest> getEventHistory() {
        return eventHistory;
    }

    public List<HangoutRequest> getOrganizedEvents() {
        return organizedEvents;
    }

    public String getAvatarColor() {
        return (avatarColor != null && !avatarColor.isEmpty()) ? avatarColor : "#C8A0C8";
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }

    public void setAvatarColor(String hex) {
        this.avatarColor = hex;
    }

}