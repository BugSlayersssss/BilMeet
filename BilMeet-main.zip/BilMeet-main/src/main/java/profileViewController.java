import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class profileViewController {

    @FXML
    private Circle profileCircle;
    @FXML
    private Button profileNameButton;
    @FXML
    private VBox eventListContainer;
    @FXML
    private VBox eventContainer;
    @FXML
    private Circle mainAvatarCircle;
    @FXML
    private Button changeAvatarColourButton;
    @FXML
    private Label nameField;
    @FXML
    private Label deptLabel;
    @FXML
    private TextField editableNameField;
    @FXML
    private TextField editableDeptField;
    @FXML
    private Label accountIdLabel;
    @FXML
    private Button saveButton;
    @FXML
    private VBox interestsVBox;

    private boolean isUpdatingInterests = false;

    public final String[] availableInterestNames = {
            "Sports", "Gym & Fitness", "Study & Co-working", "Video Games", "Board Games",
            "Coffee & Chat", "Movies & Cinema", "Coding & Tech", "Music & Jamming", "Art & Creative",
            "Language Practice", "Dining Out", "Campus Walks", "Photography", "Books & Reading",
            "Volunteering", "Networking", "Anime & Manga", "Science & Math", "Shopping"
    };

    @FXML
    public void initialize() {
        User me = SessionManager.getCurrentUser();
        if (me == null)
            return;

        if (profileNameButton != null)
            profileNameButton.setText(me.getName() + " " + me.getSurname());
        applyAvatarColour(profileCircle, me.getAvatarColor());
        applyAvatarColour(mainAvatarCircle, me.getAvatarColor());
        if (accountIdLabel != null)
            accountIdLabel.setText("Account ID: " + me.getId());

        if (changeAvatarColourButton == null) {
            if (nameField != null)
                nameField.setText(me.getName() + " " + me.getSurname());
            if (deptLabel != null)
                deptLabel.setText("Department: " + (me.getDepartment() != null ? me.getDepartment() : ""));

            if (interestsVBox != null) {
                interestsVBox.getChildren().clear();
                if (me.getInterests() == null || me.getInterests().isEmpty()) {
                    Label emptyLabel = new Label("No interests added yet.");
                    emptyLabel.setStyle("-fx-text-fill: #888888; -fx-font-style: italic;");
                    interestsVBox.getChildren().add(emptyLabel);
                } else {
                    for (String interest : me.getInterests()) {
                        Label lbl = new Label("• " + interest);
                        lbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");
                        interestsVBox.getChildren().add(lbl);
                    }
                }
            }
        } else {
            if (editableNameField != null)
                editableNameField.setText(me.getName() + " " + me.getSurname());
            if (editableDeptField != null)
                editableDeptField.setText(me.getDepartment() != null ? me.getDepartment() : "");

            if (interestsVBox != null) {
                interestsVBox.getChildren().clear();
                if (me.getInterests() != null) {
                    for (String interest : me.getInterests()) {
                        addEditableInterestRow(interest);
                    }
                }
                refreshAllChoiceBoxOptions();
            }
        }
    }

    @FXML
    public void handleAddInterestRow(ActionEvent e) {
        if (interestsVBox.getChildren().size() >= availableInterestNames.length)
            return;
        addEditableInterestRow("");
        refreshAllChoiceBoxOptions();
    }

    @FXML
    public void handleSave(ActionEvent e) {
        User me = SessionManager.getCurrentUser();
        if (me == null)
            return;

        if (editableNameField != null && !editableNameField.getText().trim().isEmpty()) {
            String[] parts = editableNameField.getText().trim().split(" ", 2);
            String newName = parts[0];
            String newSurname = parts.length > 1 ? parts[1] : "";
            me.updateProfile(newName, newSurname,
                    editableDeptField != null ? editableDeptField.getText().trim() : me.getDepartment());
        }

        me.getInterests().clear();
        for (Node child : interestsVBox.getChildren()) {
            if (child instanceof HBox) {
                @SuppressWarnings("unchecked")
                ChoiceBox<String> cb = (ChoiceBox<String>) ((HBox) child).getChildren().get(0);
                String val = cb.getValue();
                if (val != null && !val.trim().isEmpty()) {
                    me.addInterest(val);
                }
            }
        }

        Button btn = (Button) e.getSource();
        btn.setText("SAVING...");
        btn.setDisable(true);

        new Thread(() -> {
            try {
                com.google.cloud.firestore.Firestore db = FirebaseInitializer.getFirestore();
                com.google.api.core.ApiFuture<com.google.cloud.firestore.QuerySnapshot> future = db.collection("users")
                        .whereEqualTo("userMail", me.getEmail()).get();

                com.google.cloud.firestore.QuerySnapshot snapshot = future.get();
                if (!snapshot.isEmpty()) {
                    com.google.cloud.firestore.DocumentReference docRef = snapshot.getDocuments().get(0).getReference();

                    java.util.Map<String, Object> updates = new java.util.HashMap<>();
                    updates.put("name", me.getName());
                    updates.put("surname", me.getSurname());
                    updates.put("department", me.getDepartment());
                    updates.put("interests", me.getInterests());
                    updates.put("avatarColor", me.getAvatarColor());

                    docRef.update(updates).get();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            Platform.runLater(() -> {
                btn.setText("SAVED!");
                btn.setStyle(
                        "-fx-background-color: #28a745; -fx-text-fill: white; -fx-background-radius: 20; -fx-font-weight: bold;");
                btn.setDisable(false);

                try {
                    goBack(e);
                } catch (Exception ignored) {
                }
            });
        }).start();
    }

    @FXML
    public void openCurrentEventsButton(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/CurrentEvents.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void openEventHistoryButton(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/EventHistory.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void handleChangeAvatarColour(ActionEvent e) {
        String[] palette = {
                "#C8A0C8", "#4DD9D9", "#90EE90", "#FF9080", "#E8C240",
                "#A0A0FF", "#FFA07A", "#8FBC8F", "#FFD700", "#FF69B4"
        };

        User me = SessionManager.getCurrentUser();
        if (me == null)
            return;

        String current = me.getAvatarColor();
        int idx = 0;

        for (int i = 0; i < palette.length; i++) {
            if (palette[i].equalsIgnoreCase(current)) {
                idx = (i + 1) % palette.length;
                break;
            }
        }

        me.setAvatarColor(palette[idx]);

        applyAvatarColour(mainAvatarCircle, palette[idx]);
        applyAvatarColour(profileCircle, palette[idx]);
    }

    @FXML
    public void goToProfile(ActionEvent e) {
    }

    @FXML
    public void goToMenu(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void openFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent e) throws IOException {
        navigate(e, "/searchView.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void handleEditName(ActionEvent e) throws IOException {
        navigate(e, "/myProfileEditable.fxml");
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        navigate(e, "/myProfileUneditable.fxml");
    }

    @FXML
    public void openSchedule(MouseEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void openEventHistory(MouseEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/EventHistory.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void openChat(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
        Parent root = loader.load();
        ChatController ctrl = loader.getController();
        ctrl.setManagers(ChatManager.getInstance());
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void addEditableInterestRow(String selectedValue) {
        HBox row = new HBox(8);
        row.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        ChoiceBox<String> cb = new ChoiceBox<>();
        cb.setPrefWidth(180);
        cb.getItems().add("");
        cb.getItems().addAll(availableInterestNames);

        if (selectedValue != null && !selectedValue.isEmpty()) {
            cb.setValue(selectedValue);
        }

        cb.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (!isUpdatingInterests) {
                refreshAllChoiceBoxOptions();
            }
        });

        Button deleteBtn = new Button("✕");
        deleteBtn.setStyle(
                "-fx-background-color: #FF7F87; -fx-text-fill: white; -fx-background-radius: 5; -fx-cursor: hand;");
        deleteBtn.setOnAction(e -> {
            interestsVBox.getChildren().remove(row);
            refreshAllChoiceBoxOptions();
        });

        row.getChildren().addAll(cb, deleteBtn);
        interestsVBox.getChildren().add(row);
    }

    private void refreshAllChoiceBoxOptions() {
        if (interestsVBox == null)
            return;

        isUpdatingInterests = true;

        try {
            List<String> selected = new ArrayList<>();
            for (Node child : interestsVBox.getChildren()) {
                if (child instanceof HBox) {
                    @SuppressWarnings("unchecked")
                    ChoiceBox<String> cb = (ChoiceBox<String>) ((HBox) child).getChildren().get(0);
                    if (cb.getValue() != null && !cb.getValue().isEmpty()) {
                        selected.add(cb.getValue());
                    }
                }
            }

            for (Node child : interestsVBox.getChildren()) {
                if (child instanceof HBox) {
                    @SuppressWarnings("unchecked")
                    ChoiceBox<String> cb = (ChoiceBox<String>) ((HBox) child).getChildren().get(0);
                    String currentVal = cb.getValue();

                    cb.getItems().clear();
                    cb.getItems().add("");

                    for (String interest : availableInterestNames) {
                        if (!selected.contains(interest) || interest.equals(currentVal)) {
                            cb.getItems().add(interest);
                        }
                    }
                    cb.setValue(currentVal);
                }
            }
        } finally {
            isUpdatingInterests = false;
        }
    }

    private void applyAvatarColour(Circle circle, String hex) {
        if (circle == null || hex == null || hex.isEmpty())
            return;
        try {
            circle.setFill(Color.web(hex));
        } catch (Exception ignored) {
        }
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}