import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Callback;


import com.google.cloud.firestore.ListenerRegistration;

import javafx.application.Platform;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public class ChatController {

    @FXML private VBox      chatListContainer;   
    @FXML private VBox      groupListContainer;   

    // Right panel
    @FXML private ListView<Message> messageListView;
    @FXML private TextField         messageInputField;
    @FXML private TextField         newChatEmailField;
    @FXML private Label             chatHeaderLabel;  

   
    @FXML private Button pendingBadge;

    
    @FXML private Circle sidebarProfileCircle;
    @FXML private Button profileNameButton;

    
    private ListenerRegistration chatListener;
    private ListenerRegistration messageListener;

    private ChatManager    chatManager;
    private Chat           currentChat;
    private DataManager    dataManager = new DataManager();

    
    @FXML
    public void initialize() {
        User me = SessionManager.getCurrentUser();
        if (me != null) {
            if (profileNameButton != null)
                profileNameButton.setText(me.getName() + " " + me.getSurname());
            if (sidebarProfileCircle != null) {
                String hex = me.getAvatarColor();
                if (hex != null && !hex.isEmpty()) {
                    try { sidebarProfileCircle.setFill(Color.web(hex)); }
                    catch (Exception ignored) {}
                }
            }
            // Update pending-requests badge count
            if (pendingBadge != null) {
                int count = dataManager.getPendingFriendRequests(me.getEmail()).size();
                pendingBadge.setText(String.valueOf(count));
            }
        }
    }

    
    public void setManagers(ChatManager chatManager, UserManager userManager) {
        this.chatManager = chatManager;

        // Configure message cell factory
        if (messageListView != null) {
            messageListView.setCellFactory(new Callback<ListView<Message>, ListCell<Message>>() {
                @Override
                public ListCell<Message> call(ListView<Message> lv) {
                    return new MessageCell(SessionManager.getCurrentUser());
                }
            });
        }

        loadUserChats();
        startChatListListener();
    }

    
   private void loadUserChats() {
        User me = SessionManager.getCurrentUser();
        if (me == null) return;

        // Spin up a new background thread for heavy Firebase operations
        new Thread(() -> {
            // THIS IS HEAVY: Do it in the background
            List<Chat> userChats = dataManager.getChatsForUserFromFirebase(me);
            
            if (chatManager == null) chatManager = ChatManager.getInstance();
            chatManager.setAllChats(userChats);
            
            userChats.sort((chat1, chat2) -> {
                LocalDateTime time1 = chat1.getLastMessageTime();
                LocalDateTime time2 = chat2.getLastMessageTime();
                return time2.compareTo(time1);
            });

            // Once data is ready, update the UI on the JavaFX Application Thread
            Platform.runLater(() -> {
                // ---> FIX: CLEAR THE UI HERE, RIGHT BEFORE ADDING THE NEW CHATS <---
                if (chatListContainer != null) chatListContainer.getChildren().clear();
                if (groupListContainer != null) groupListContainer.getChildren().clear(); 

                for (Chat chat : userChats) {
                    String displayName = chat.getDisplayName(me);
                    
                    if (chat.isPrivate()) {
                        HBox row = buildChatRow(chat, displayName, false);
                        if (chatListContainer != null) chatListContainer.getChildren().add(row);
                    } else {
                        HBox row = buildChatRow(chat, displayName, true);
                        if (groupListContainer != null) groupListContainer.getChildren().add(row);
                    }
                }
            });
        }).start();
    }
   private HBox buildChatRow(Chat chat, String name, boolean isGroup) {
        HBox row = new HBox(8);
        row.setStyle("-fx-padding: 4; -fx-cursor: hand;");
        row.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // ---> NEW: Figure out the other person's avatar colour! <---
        String hexColor = isGroup ? "#A0A0FF" : "#A0C8FF"; // Default colors
        if (!isGroup) {
            User me = SessionManager.getCurrentUser();
            for (User p : chat.getParticipants()) {
                // Find the person who IS NOT me, and grab their colour
                if (!p.getEmail().equals(me.getEmail()) && p.getAvatarColor() != null && !p.getAvatarColor().isEmpty()) {
                    hexColor = p.getAvatarColor();
                    break;
                }
            }
        }

        Circle avatar = new Circle(16);
        try {
            avatar.setFill(Color.web(hexColor));
        } catch (Exception e) {
            avatar.setFill(Color.web("#A0C8FF")); // Fallback if colour is broken
        }
        
        avatar.setStroke(Color.BLACK);
        avatar.setStrokeWidth(1.0);

        Label nameLbl = new Label(name);
        nameLbl.setStyle("-fx-font-size: 12;");

        row.getChildren().addAll(avatar, nameLbl);
        row.setOnMouseClicked(e -> {
            currentChat = chat;
            if (chatHeaderLabel != null)
                chatHeaderLabel.setText("CHAT WITH " + name.toUpperCase() + "...");
            startMessageListener(chat);
            refreshMessageDisplay();
        });
        return row;
    }
    @FXML
    public void handleStartNewChat(ActionEvent event) {
        if (newChatEmailField == null) return;
        String targetEmail = newChatEmailField.getText().trim();
        User me = SessionManager.getCurrentUser();
        User target = dataManager.getUserByEmail(targetEmail);

        if (me == null || target == null || target.getEmail().equals(me.getEmail())) {
            System.out.println("Error: User not found or tried to chat with yourself.");
            return;
        }

        Chat newChat = dataManager.getOrCreatePrivateChat(me, target);
        if (newChat == null) return;

        List<Chat> chats = dataManager.getChatsForUserFromFirebase(me);
        chatManager.setAllChats(chats);
        newChatEmailField.clear();
        loadUserChats();

        currentChat = newChat;
        if (chatHeaderLabel != null)
            chatHeaderLabel.setText("CHAT WITH " + target.getName().toUpperCase() + "...");
        startMessageListener(currentChat);
        refreshMessageDisplay();
    }

    @FXML
    public void handleSendMessage(ActionEvent event) {
        if (messageInputField == null) return;
        String content = messageInputField.getText().trim();
        if (currentChat == null || content.isEmpty()) return;

        User me = SessionManager.getCurrentUser();
        if (me == null) return;

        chatManager.sendMessage(currentChat, content, me);
        messageInputField.clear();

        List<Message> refreshed = dataManager.getMessagesForChat(currentChat.getChatId());
        currentChat.getMessages().clear();
        currentChat.getMessages().addAll(refreshed);
        refreshMessageDisplay();
    }

    private void refreshMessageDisplay() {
        if (currentChat != null && messageListView != null) {
            messageListView.setItems(
                    FXCollections.observableArrayList(currentChat.getMessages()));
            int size = currentChat.getMessages().size();
            if (size > 0) messageListView.scrollTo(size - 1);
        }
    }

    private void startChatListListener() {
        User me = SessionManager.getCurrentUser();
        if (me == null) return;
        if (chatListener != null) chatListener.remove();

        chatListener = FirebaseInitializer.getFirestore()
                .collection("chats")
                .addSnapshotListener((snapshot, error) -> {
                    if (error != null) { error.printStackTrace(); return; }
                    if (snapshot == null) return;
                    
                    // You are currently on a Firebase background thread.
                    // DO THE HEAVY LIFTING HERE, NOT IN Platform.runLater!
                    List<Chat> chats = dataManager.getChatsForUserFromFirebase(me);
                    
                    if (chatManager == null) chatManager = ChatManager.getInstance();
                    chatManager.setAllChats(chats);

                    // Now that data is fetched, update the UI
                    Platform.runLater(() -> {
                        loadUserChats(); 
                    });
                });
    }

    private void startMessageListener(Chat chat) {
        if (chat == null) return;
        if (messageListener != null) messageListener.remove();

        messageListener = FirebaseInitializer.getFirestore()
                .collection("messages")
                .whereEqualTo("chatId", chat.getChatId())
                .addSnapshotListener((snapshot, error) -> {
                    if (error != null) { error.printStackTrace(); return; }
                    if (snapshot == null) return;
                    Platform.runLater(() -> {
                        List<Message> msgs = dataManager.getMessagesForChat(chat.getChatId());
                        chat.getMessages().clear();
                        chat.getMessages().addAll(msgs);
                        refreshMessageDisplay();
                    });
                });
    }
     @FXML
public void openChat(ActionEvent e) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
        Parent root = loader.load();
        
        ChatController ctrl = loader.getController();
        if (ctrl != null) {
            ctrl.setManagers(ChatManager.getInstance(), new UserManager());
        }

        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
    } catch (IOException ex) {
        System.err.println("FXML Yüklenemedi: " + ex.getMessage());
        ex.printStackTrace();
    } catch (ClassCastException ex) {
        System.err.println("Tıklanan nesne bir Node değil!");
    }
}

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        cleanup();
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML public void goToProfile(ActionEvent e)           throws IOException { cleanup(); navigate(e, "/myProfileUneditable.fxml"); }
    @FXML public void goToMenu(ActionEvent e)              throws IOException { cleanup(); navigate(e, "/AvailableEvents.fxml"); }
    @FXML public void goToFriends(ActionEvent e)           throws IOException { cleanup(); navigate(e, "/friendView.fxml"); }
    @FXML public void goToSearch(ActionEvent e)            throws IOException { cleanup(); navigate(e, "/searchView.fxml"); }
    @FXML public void goToCreateEventScreen(ActionEvent e) throws IOException { cleanup(); navigate(e, "/createEvent.fxml"); }

    @FXML
    public void openSchedule(ActionEvent e) throws IOException {
        cleanup();
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void cleanup() {
        if (chatListener    != null) chatListener.remove();
        if (messageListener != null) messageListener.remove();
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
