import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CurrentEventsController {
    @FXML private VBox eventListContainer;
    private static CurrentEventsController instance;

    public void initialize() {
        instance = this;
        EventController.isCurrentEventsPage = true; // Tell the cards we are here!
        loadEvents();
    }

    public static CurrentEventsController getInstance() { return instance; }

    public void loadEvents() {
        if (eventListContainer == null) return;
        eventListContainer.getChildren().clear();
        
        User me = SessionManager.getCurrentUser();
        List<HangoutRequest> allEvents = EventManager.getInstance().getAllEvents();

        for (HangoutRequest req : allEvents) {
            boolean inEvent = false;
            if (req.getParticipants() != null) {
                for (User p : req.getParticipants()) {
                    if (p.getEmail().equals(me.getEmail())) inEvent = true;
                }
            }
            if (inEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/event.fxml"));
                    Node card = loader.load();
                    ((EventCardController) loader.getController()).setData(req);
                    eventListContainer.getChildren().add(card);
                } catch (IOException ex) { ex.printStackTrace(); }
            }
        }
    }

    public void replaceCardWithDetails(Node oldCard, HangoutRequest request) {
        try {
            int idx = eventListContainer.getChildren().indexOf(oldCard);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/eventDetails.fxml"));
            Node detailNode = loader.load();
            ((EventDetailsController) loader.getController()).loadDetailedData(request);
            eventListContainer.getChildren().set(idx, detailNode);
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        EventController.isCurrentEventsPage = false; // Reset the flag when leaving!
        Parent root = FXMLLoader.load(getClass().getResource("/myProfileUneditable.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}