import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Collections;

public class DataManager {

    private final Firestore db;

    public DataManager() {
        this.db = FirebaseInitializer.getFirestore();
    }

    public boolean validateLogin(String email, String password) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();

            QuerySnapshot querySnapshot = query.get();

            if (querySnapshot.isEmpty()) {
                System.out.println("No user found with email: " + email);
                return false;
            }

            DocumentSnapshot document = querySnapshot.getDocuments().get(0);
            String storedPassword = document.getString("userPassword");

            System.out.println("User found: " + document.getData());

            return storedPassword != null && storedPassword.equals(password);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean userExists(String email) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();

            return !query.get().isEmpty();

        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }

    public boolean createUser(String name, String surname, String department, String password, String email) {
        try {
            if (userExists(email)) {
                System.out.println("User already exists.");
                return false;
            }

            java.util.Random random = new java.util.Random();
            int randomId = 10000000 + random.nextInt(90000000); 
            String accountId = String.valueOf(randomId);
            Map<String, Object> userData = new HashMap<>();
            userData.put("userId", accountId);
            userData.put("name", name);
            userData.put("surname", surname);
            userData.put("department", department);
            userData.put("userPassword", password);
            userData.put("userMail", email);
            userData.put("interests", new ArrayList<String>());
            userData.put("friends", new ArrayList<String>());

            db.collection("users").add(userData).get();

            System.out.println("User created successfully.");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public User getUserByEmail(String email) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();

            QuerySnapshot querySnapshot = query.get();

            if (querySnapshot.isEmpty()) {
                return null;
            }

            DocumentSnapshot document = querySnapshot.getDocuments().get(0);

            String name = document.getString("name");
            String surname = document.getString("surname");
            String userPassword = document.getString("userPassword");
            String userMail = document.getString("userMail");
            String department = document.getString("department");

            User user = new User(name, surname, userMail, userPassword, department);
            
            // ---> NEW: Load the ID (with a fallback for your older test accounts) <---
            String fetchedId = document.getString("userId");
            user.setUserId(fetchedId != null ? fetchedId : "00000000");
            // ---> NEW: Load the saved schedule matrix from Firebase! <---
            loadUserScheduleFromDoc(document, user);
            // ---> NEW: Load the saved interests from Firebase! <---
            List<String> interests = (List<String>) document.get("interests");
            if (interests != null) {
                for (String interest : interests) {
                    user.addInterest(interest);
                }
            }
            String avatarColor = document.getString("avatarColor");
            if (avatarColor != null) user.setAvatarColor(avatarColor);
            return user;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void printAllUsers() {
        try {
            ApiFuture<QuerySnapshot> future = db.collection("users").get();
            QuerySnapshot snapshot = future.get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                System.out.println(doc.getData());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public User authenticateAndGetUser(String email, String password) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();

            QuerySnapshot querySnapshot = query.get();

            if (querySnapshot.isEmpty()) {
                return null;
            }

            DocumentSnapshot document = querySnapshot.getDocuments().get(0);
            String storedPassword = document.getString("userPassword");

            if (storedPassword == null || !storedPassword.equals(password)) {
                return null;
            }

            String name = document.getString("name");
            String surname = document.getString("surname");
            String department = document.getString("department");
            String userMail = document.getString("userMail");

            User user = new User(name, surname, userMail, storedPassword, department);
            
            // ---> NEW: Load the ID <---
            String fetchedId = document.getString("userId");
            user.setUserId(fetchedId != null ? fetchedId : "00000000");
            // ---> NEW: Load the saved schedule matrix from Firebase! <---
            loadUserScheduleFromDoc(document, user);
            List<String> interests = (List<String>) document.get("interests");
            if (interests != null) {
                for (String interest : interests) {
                    user.addInterest(interest);
                }
            }

            String avatarColor = document.getString("avatarColor");
            if (avatarColor != null) user.setAvatarColor(avatarColor);
            return user;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean createEvent(HangoutRequest event) {
        try {
            Map<String, Object> eventData = new HashMap<>();

            eventData.put("name", event.getName());
            eventData.put("location", event.getLocation());
            eventData.put("startHour", event.getStartHour());
            eventData.put("endHour", event.getEndHour());
            eventData.put("startTime", event.getStartTime());
            eventData.put("endTime", event.getEndTime());
            eventData.put("day", event.getDay());
            eventData.put("quota", event.getQuota());
            eventData.put("tags", event.getTags());
            // ---> NEW: Save the minutes! <---
            eventData.put("startMin", event.getStartMin());
            eventData.put("endMin", event.getEndMin());

            eventData.put("startTime", event.getStartTime());
            eventData.put("endTime", event.getEndTime());
            eventData.put("day", event.getDay());

            if (event.getOrganiser() != null) {
                eventData.put("organiserEmail", event.getOrganiser().getEmail());
                eventData.put("organiserName", event.getOrganiser().getUserName());
            } else {
                eventData.put("organiserEmail", "");
                eventData.put("organiserName", "");
            }

            List<String> participantEmails = new ArrayList<>();
            for (User user : event.getParticipants()) {
                participantEmails.add(user.getEmail());
            }
            eventData.put("participantEmails", participantEmails);

            db.collection("events").add(eventData).get();
            System.out.println("Event created successfully in Firebase.");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<HangoutRequest> getAllEventsFromFirebase() {
        List<HangoutRequest> events = new ArrayList<>();

        try {
            ApiFuture<QuerySnapshot> future = db.collection("events").get();
            QuerySnapshot snapshot = future.get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String name = doc.getString("name");
                String location = doc.getString("location");

                int startHour = getIntFromDoc(doc, "startHour", 0);
                int endHour = getIntFromDoc(doc, "endHour", 0);
                int quota = getIntFromDoc(doc, "quota", 1);
                
                // ---> NEW: Load the day from Firebase (default to 1 = Monday) <---
                int day = getIntFromDoc(doc, "day", 1);
                // ---> NEW: Load the minutes from Firebase <---
                int startMin = getIntFromDoc(doc, "startMin", 0);
                int endMin = getIntFromDoc(doc, "endMin", 0);
;

                List<String> tags = (List<String>) doc.get("tags");
                if (tags == null) tags = new ArrayList<>();

                String organiserEmail = doc.getString("organiserEmail");
                User organiser = getUserByEmail(organiserEmail);

                // Fetch the participant emails from Firebase and load the users
                List<String> participantEmails = (List<String>) doc.get("participantEmails");
                List<User> participants = new ArrayList<>();
                
                if (participantEmails != null) {
                    for (String email : participantEmails) {
                        User participant = getUserByEmail(email);
                        if (participant != null) {
                            participants.add(participant);
                        }
                    }
                }

                HangoutRequest event = new HangoutRequest(
                    name,
                    location,
                    startHour,
                    startMin,
                    endHour,
                    endMin,
                    tags,
                    participants, 
                    quota,
                    organiser
                );

                // ---> NEW: Set the day on the event object <---
                event.setDay(day);

                events.add(event);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return events;
    }
    // ── Helper method to load the saved schedule ──────────────────────────────
    private void loadUserScheduleFromDoc(DocumentSnapshot document, User user) {
        Map<String, Object> scheduleMap = (Map<String, Object>) document.get("schedule");
        
        if (scheduleMap != null && user.getSchedule() != null) {
            boolean[][] loadedSlots = new boolean[7][24];
            
            for (int d = 0; d < 7; d++) {
                for (int h = 0; h < 24; h++) {
                    Object val = scheduleMap.get(d + "_" + h);
                    if (val instanceof Boolean) {
                        loadedSlots[d][h] = (Boolean) val;
                    }
                }
            }
            user.getSchedule().setBusySlots(loadedSlots);
        }
    }

    private int getIntFromDoc(DocumentSnapshot doc, String field, int defaultVal) {
        Object val = doc.get(field);
        if (val == null) return defaultVal;
        
        if (val instanceof Number) {
            return ((Number) val).intValue();
        } else if (val instanceof String) {
            try {
                return Integer.parseInt((String) val);
            } catch (NumberFormatException e) {
                return defaultVal;
            }
        }
        return defaultVal;
    }
    
    public boolean createFriendRequest(User sender, User receiver) {
        try {
            Map<String, Object> requestData = new HashMap<>();
            requestData.put("senderEmail", sender.getEmail());
            requestData.put("receiverEmail", receiver.getEmail());
            requestData.put("status", "awaiting");

            db.collection("friend_requests").add(requestData).get();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean createChat(Chat chat) {
        try {
            Map<String, Object> chatData = new HashMap<>();
            chatData.put("isPrivate", chat.isPrivate());

            List<String> participantEmails = new ArrayList<>();
            for (User user : chat.getParticipants()) {
                participantEmails.add(user.getEmail());
            }
            chatData.put("participantEmails", participantEmails);

            if (!chat.isPrivate()) {
                chatData.put("groupName", chat.getGroupName());
            }

            DocumentReference docRef = db.collection("chats").add(chatData).get();

            String firebaseChatId = docRef.getId();
            docRef.update("chatId", firebaseChatId).get();

            chat.setChatId(firebaseChatId);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean saveMessage(Chat chat, Message message) {
        try {
            Map<String, Object> msgData = new HashMap<>();
            msgData.put("chatId", chat.getChatId());
            msgData.put("senderEmail", message.getSender().getEmail());
            msgData.put("content", message.getContent());
            msgData.put("sentAt", message.getSentAt().toString());

            db.collection("messages").add(msgData).get();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    // ── GET ALL USERS (For the Match Algorithm) ────────────────────────────────
    public List<User> getAllUsers() {
        List<User> allUsers = new ArrayList<>();
        try {
            QuerySnapshot snapshot = db.collection("users").get().get();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String name = doc.getString("name");
                String surname = doc.getString("surname");
                String userMail = doc.getString("userMail");
                String password = doc.getString("userPassword");
                String department = doc.getString("department");

                User user = new User(name == null ? "" : name, 
                                     surname == null ? "" : surname, 
                                     userMail, password, department);
                                     
                                     
                String fetchedId = doc.getString("userId");
                user.setUserId(fetchedId != null ? fetchedId : "00000000");

                // Load their interests so the algorithm can score them!
                List<String> interests = (List<String>) doc.get("interests");
                if (interests != null) {
                    for (String interest : interests) {
                        user.addInterest(interest);
                    }
                }
                String avatarColor = doc.getString("avatarColor");
            if (avatarColor != null) user.setAvatarColor(avatarColor);
                allUsers.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allUsers;
    }
   
    public List<User> searchUsersByName(String searchQuery) {
        List<User> foundUsers = new ArrayList<>();

        try {
            // 1. Fetch all users from the database
            QuerySnapshot snapshot = db.collection("users").get().get();

            // 2. Make the search query lowercase to avoid capitalization bugs
            String queryLower = searchQuery.toLowerCase().trim();

            // 3. Loop through everyone and look for matches
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String name = doc.getString("name");
                String surname = doc.getString("surname");
                
                if (name == null) name = "";
                if (surname == null) surname = "";

                String fullName = (name + " " + surname).toLowerCase();

                // If the user's full name contains the search text, add them!
                if (fullName.contains(queryLower)) {
                    String userMail = doc.getString("userMail");
                    String userPassword = doc.getString("userPassword");
                    String department = doc.getString("department");
                    
                    // Create the user object
                    User user = new User(name, surname, userMail, userPassword, department);
                    
                    // Load Account ID
                    String fetchedId = doc.getString("userId");
                    user.setUserId(fetchedId != null ? fetchedId : "00000000");

                    // Load Interests
                    List<String> interests = (List<String>) doc.get("interests");
                    if (interests != null) {
                        for (String interest : interests) {
                            user.addInterest(interest);
                        }
                    }

                    // ---> NEW: Load Avatar Colour <---
                    String avatarColor = doc.getString("avatarColor");
                    if (avatarColor != null) {
                        user.setAvatarColor(avatarColor);
                    }
                    
                    // Finally, add them to the list!
                    foundUsers.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return foundUsers;
    }

    public List<User> getFriendsForUser(String userEmail) {
        List<User> friends = new ArrayList<>();

        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", userEmail)
                    .get();

            QuerySnapshot snapshot = query.get();
            if (snapshot.isEmpty()) return friends;

            DocumentSnapshot userDoc = snapshot.getDocuments().get(0);
            List<String> friendEmails = (List<String>) userDoc.get("friends");

            if (friendEmails == null) return friends;

            for (String email : friendEmails) {
                User friend = getUserByEmail(email);
                if (friend != null) {
                    friends.add(friend);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return friends;
    }

    public boolean addFriendToBothUsers(String email1, String email2) {
        try {
            QuerySnapshot snap1 = db.collection("users").whereEqualTo("userMail", email1).get().get();
            QuerySnapshot snap2 = db.collection("users").whereEqualTo("userMail", email2).get().get();

            if (snap1.isEmpty() || snap2.isEmpty()) return false;

            DocumentReference doc1 = snap1.getDocuments().get(0).getReference();
            DocumentReference doc2 = snap2.getDocuments().get(0).getReference();

            doc1.update("friends", FieldValue.arrayUnion(email2)).get();
            doc2.update("friends", FieldValue.arrayUnion(email1)).get();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<FriendRequest> getPendingFriendRequests(User receiver) {
        List<FriendRequest> requests = new ArrayList<>();

        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("receiverEmail", receiver.getEmail())
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String senderEmail = doc.getString("senderEmail");
                User sender = getUserByEmail(senderEmail);
                if (sender != null) {
                    requests.add(new FriendRequest(sender));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return requests;
    }

    public boolean updateFriendRequestStatus(String senderEmail, String receiverEmail, String newStatus) {
        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("senderEmail", senderEmail)
                    .whereEqualTo("receiverEmail", receiverEmail)
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            if (snapshot.isEmpty()) return false;

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                doc.getReference().update("status", newStatus).get();
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean joinEvent(String eventName, String userEmail) {
        try {
            QuerySnapshot snapshot = db.collection("events")
                    .whereEqualTo("name", eventName)
                    .get()
                    .get();

            if (snapshot.isEmpty()) return false;

            DocumentReference eventRef = snapshot.getDocuments().get(0).getReference();
            eventRef.update("participantEmails", FieldValue.arrayUnion(userEmail)).get();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Chat> getChatsForUserFromFirebase(User currentUser) {
        List<Chat> chats = new ArrayList<>();

        try {
            QuerySnapshot snapshot = db.collection("chats").get().get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                List<String> participantEmails = (List<String>) doc.get("participantEmails");
                if (participantEmails == null || !participantEmails.contains(currentUser.getEmail())) {
                    continue;
                }

                Boolean isPrivate = doc.getBoolean("isPrivate");
                Chat chat = new Chat(isPrivate != null ? isPrivate : true);
                String groupName = doc.getString("groupName");

                if (groupName != null) {
                    chat.setGroupName(groupName);
                }

                Object firebaseChatId = doc.get("chatId");
                if (firebaseChatId != null) {
                    chat.setChatId((String) firebaseChatId);
                }

                for (String email : participantEmails) {
                    User user = getUserByEmail(email);
                    if (user != null) {
                        chat.addParticipants(user);
                    }
                }

                List<Message> messages = getMessagesForChat((String) doc.get("chatId"));
                for (Message m : messages) {
                    chat.addMessage(m);
                }

                chats.add(chat);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return chats;
    }

    public List<Message> getMessagesForChat(String chatId) {
        List<Message> messages = new ArrayList<>();

        try {
            QuerySnapshot snapshot = db.collection("messages")
                    .whereEqualTo("chatId", chatId)
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String senderEmail = doc.getString("senderEmail");
                String content = doc.getString("content");
                String sentAtString = doc.getString("sentAt");

                User sender = getUserByEmail(senderEmail);

                if (sender != null && content != null) {
                    LocalDateTime sentAt;

                    if (sentAtString != null && !sentAtString.equals("")) {
                        sentAt = LocalDateTime.parse(sentAtString);
                    } else {
                        sentAt = LocalDateTime.now();
                    }

                    Message message = new Message(content, sender, sentAt);
                    messages.add(message);
                }
            }

            Collections.sort(messages, new java.util.Comparator<Message>() {
                @Override
                public int compare(Message m1, Message m2) {
                    return m1.getSentAt().compareTo(m2.getSentAt());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

        return messages;
    }


    public Chat getOrCreatePrivateChat(User user1, User user2) {
        try {
            QuerySnapshot snapshot = db.collection("chats").get().get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                List<String> participantEmails = (List<String>) doc.get("participantEmails");
                Boolean isPrivate = doc.getBoolean("isPrivate");

                if (Boolean.TRUE.equals(isPrivate)
                        && participantEmails != null
                        && participantEmails.size() == 2
                        && participantEmails.contains(user1.getEmail())
                        && participantEmails.contains(user2.getEmail())) {

                    Chat chat = new Chat(true);
                    chat.setChatId(doc.getString("chatId"));

                    chat.addParticipants(user1);
                    chat.addParticipants(user2);

                    List<Message> messages = getMessagesForChat(doc.getString("chatId"));
                    for (Message m : messages) {
                        chat.addMessage(m);
                    }

                    return chat;
                }
            }

            Chat newChat = new Chat(true);
            newChat.addParticipants(user1);
            newChat.addParticipants(user2);
            createChat(newChat);
            return newChat;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean updatePassword(String email, String newPassword) {
        try {
            QuerySnapshot snapshot = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get()
                    .get();

            if (snapshot.isEmpty()) return false;

            DocumentReference userRef = snapshot.getDocuments().get(0).getReference();
            userRef.update("userPassword", newPassword).get();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

   public Chat getOrCreateGroupChat(String eventName, List<User> participants) {
        try {
            // 1. Convert User objects to a list of emails
            List<String> participantEmails = new ArrayList<>();
            for (User u : participants) {
                participantEmails.add(u.getEmail());
            }

            // 2. Search for an existing group chat with this event's name
            QuerySnapshot snapshot = db.collection("chats")
                    .whereEqualTo("isPrivate", false)
                    .whereEqualTo("groupName", eventName)
                    .get()
                    .get();

            if (!snapshot.isEmpty()) {
                // 3. CHAT EXISTS: Update the participant list in Firebase so the new user is included
                DocumentSnapshot doc = snapshot.getDocuments().get(0);
                doc.getReference().update("participantEmails", participantEmails).get();

                Chat existingChat = new Chat(false);
                existingChat.setGroupName(eventName);
                existingChat.setChatId(doc.getString("chatId"));

                for (User u : participants) {
                    existingChat.addParticipants(u);
                }

                // Load existing messages so the new user can read chat history
                List<Message> messages = getMessagesForChat(doc.getString("chatId"));
                for (Message m : messages) {
                    existingChat.addMessage(m);
                }

                return existingChat;
            }

            // 4. CHAT DOES NOT EXIST: Create a brand new group chat
            Chat newChat = new Chat(false);
            newChat.setGroupName(eventName);
            for (User u : participants) {
                newChat.addParticipants(u);
            }

            Map<String, Object> chatData = new HashMap<>();
            chatData.put("isPrivate", false);
            chatData.put("groupName", eventName);
            chatData.put("participantEmails", participantEmails);

            DocumentReference docRef = db.collection("chats").add(chatData).get();
            String chatId = docRef.getId();
            docRef.update("chatId", chatId).get();

            newChat.setChatId(chatId);

            return newChat;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Map<String, Object>> getPastEvents(String userEmail) {
        List<Map<String, Object>> pastEvents = new ArrayList<>();
        try {
            // Firebase makes this super easy with "whereArrayContains"!
            QuerySnapshot snapshot = db.collection("past_events")
                    .whereArrayContains("participantEmails", userEmail)
                    .get().get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                pastEvents.add(doc.getData());
            }
            
            // Reverse the list so the most recent ones show at the top
            Collections.reverse(pastEvents); 
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pastEvents;
    }
    public void deleteExpiredEventData(String eventName) {
        // Run on a background thread to prevent UI freezing
        new Thread(() -> {
            try {
                // 1. Find and delete the event from the 'events' collection
                QuerySnapshot eventSnapshot = db.collection("events")
                        .whereEqualTo("name", eventName)
                        .get().get();
                
                for (DocumentSnapshot doc : eventSnapshot.getDocuments()) {
                    db.collection("past_events").add(doc.getData()).get();
                    doc.getReference().delete();
                }

                // 2. Find the associated group chat
                QuerySnapshot chatSnapshot = db.collection("chats")
                        .whereEqualTo("isPrivate", false)
                        .whereEqualTo("groupName", eventName)
                        .get().get();

                for (DocumentSnapshot chatDoc : chatSnapshot.getDocuments()) {
                    String chatId = chatDoc.getString("chatId");

                    // 3. Find and delete all messages associated with this chat
                    if (chatId != null) {
                        QuerySnapshot messageSnapshot = db.collection("messages")
                                .whereEqualTo("chatId", chatId)
                                .get().get();
                        
                        for (DocumentSnapshot msgDoc : messageSnapshot.getDocuments()) {
                            msgDoc.getReference().delete();
                        }
                    }
                    
                    // 4. Finally, delete the chat document itself
                    chatDoc.getReference().delete();
                }
                
                System.out.println("Cleaned up expired event and chat: " + eventName);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
    public boolean friendRequestAlreadyExists(String senderEmail, String receiverEmail) {
        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("senderEmail", senderEmail)
                    .whereEqualTo("receiverEmail", receiverEmail)
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            if (!snapshot.isEmpty()) {
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<FriendRequest> getPendingFriendRequests(String receiverEmail) {
        List<FriendRequest> requests = new ArrayList<>();

        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("receiverEmail", receiverEmail)
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                String senderEmail = doc.getString("senderEmail");
                User sender = getUserByEmail(senderEmail);

                if (sender != null) {
                    FriendRequest request = new FriendRequest(sender);
                    requests.add(request);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return requests;
    }

    public boolean acceptFriendRequest(String senderEmail, String receiverEmail) {
        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("senderEmail", senderEmail)
                    .whereEqualTo("receiverEmail", receiverEmail)
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                doc.getReference().update("status", "accepted").get();
            }

            addFriendToUser(senderEmail, receiverEmail);
            addFriendToUser(receiverEmail, senderEmail);

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean rejectFriendRequest(String senderEmail, String receiverEmail) {
        try {
            QuerySnapshot snapshot = db.collection("friend_requests")
                    .whereEqualTo("senderEmail", senderEmail)
                    .whereEqualTo("receiverEmail", receiverEmail)
                    .whereEqualTo("status", "awaiting")
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                doc.getReference().update("status", "rejected").get();
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public void addFriendToUser(String userEmail, String friendEmail) {
        try {
            QuerySnapshot snapshot = db.collection("users")
                    .whereEqualTo("userMail", userEmail)
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                List<String> friends = (List<String>) doc.get("friends");

                if (friends == null) {
                    friends = new ArrayList<String>();
                }

                if (!friends.contains(friendEmail)) {
                    friends.add(friendEmail);
                    doc.getReference().update("friends", friends).get();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void savePrivateChat(Chat chat) {
        try {
            List<String> participantEmails = new ArrayList<String>();

            for (User user : chat.getParticipants()) {
                participantEmails.add(user.getEmail());
            }

            Map<String, Object> chatData = new HashMap<String, Object>();
            chatData.put("chatId", chat.getChatId());
            chatData.put("isPrivate", true);
            chatData.put("participants", participantEmails);

            db.collection("chats").document(chat.getChatId()).set(chatData).get();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean privateChatAlreadyExists(String firstEmail, String secondEmail) {
        try {
            QuerySnapshot snapshot = db.collection("chats")
                    .whereEqualTo("isPrivate", true)
                    .get()
                    .get();

            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                List<String> participants = (List<String>) doc.get("participants");

                if (participants != null && participants.size() == 2) {
                    boolean firstMatch = participants.contains(firstEmail);
                    boolean secondMatch = participants.contains(secondEmail);

                    if (firstMatch && secondMatch) {
                        return true;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ── Schedule persistence ───────────────────────────────────────────────────

    /**
     * Saves the 7×24 busy-slots matrix to Firestore under the user document.
     * The matrix is flattened to a Map<String, Boolean> keyed "d_h" (day_hour).
     *
     * @param email     the user's email (used to find their document)
     * @param busySlots 7×24 boolean matrix; true = BUSY
     */
    public void saveSchedule(String email, boolean[][] busySlots) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();
            QuerySnapshot snapshot = query.get();
            if (snapshot.isEmpty()) return;

            DocumentSnapshot doc = snapshot.getDocuments().get(0);
            DocumentReference ref = db.collection("users").document(doc.getId());

            // Flatten the 7×24 matrix into a map
            java.util.Map<String, Object> scheduleMap = new java.util.HashMap<>();
            for (int d = 0; d < 7; d++) {
                for (int h = 0; h < 24; h++) {
                    scheduleMap.put(d + "_" + h, busySlots[d][h]);
                }
            }

            ref.update("schedule", scheduleMap).get();
            System.out.println("Schedule saved for " + email);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── Avatar colour persistence ──────────────────────────────────────────────

    /**
     * Saves the user's chosen avatar colour hex string to Firestore.
     *
     * @param email    the user's email
     * @param hexColor CSS hex colour, e.g. "#C8A0C8"
     */
    public void saveAvatarColor(String email, String hexColor) {
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users")
                    .whereEqualTo("userMail", email)
                    .get();
            QuerySnapshot snapshot = query.get();
            if (snapshot.isEmpty()) return;

            DocumentSnapshot doc = snapshot.getDocuments().get(0);
            db.collection("users").document(doc.getId())
              .update("avatarColor", hexColor).get();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}