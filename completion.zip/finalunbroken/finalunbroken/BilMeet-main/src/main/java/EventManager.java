import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EventManager {
    private static EventManager instance;
    private List<HangoutRequest> events;

    private EventManager() {
        this.events = new ArrayList<>();
    }

    public static EventManager getInstance() {
        if (instance == null) {
            instance = new EventManager();
        }
        return instance;
    }

    public void addEvent(HangoutRequest event) {
        events.add(event);
    }

    public List<HangoutRequest> getAllEvents() {
        return events;
    }

    public void handleJoinEvent(HangoutRequest event, User user) {
        if (event == null || user == null) {
            return;
        }

        DataManager dataManager = new DataManager();
        boolean joined = dataManager.joinEvent(event.getName(), user.getEmail());

        if (joined) {
            event.addParticipant(user);

            dataManager.getOrCreateGroupChat(event.getName(), event.getParticipants());

            ChatManager chatManager = ChatManager.getInstance();
            Chat existingChat = chatManager.findGroupChatByName(event.getName());

            if (existingChat == null) {
                Chat newChat = chatManager.createGroupChat(event.getParticipants());
                newChat.setGroupName(event.getName());
            } else {
                existingChat.addParticipants(user);
            }
        }
    }

    public void handleLeaveEvent(HangoutRequest event, User user) {
        if (event != null && user != null) {
            event.removeParticipant(user);
        }
    }

    public List<HangoutRequest> handleFilterByTag(String tag) {
        List<HangoutRequest> filteredEvents = new ArrayList<>();

        if (tag == null || tag.trim().isEmpty()) {
            return events;
        }

        // Normalize the clicked tag to lowercase and spaces
        String wantedTag = tag.trim().toLowerCase().replace("_", " ");

        for (HangoutRequest event : events) {
            if (event.getTags() == null) continue;

            for (String eventTag : event.getTags()) {
                if (eventTag != null) {
                    // Normalize the event's tag to match
                    String normalizedEventTag = eventTag.trim().toLowerCase().replace("_", " ");

                    if (normalizedEventTag.equals(wantedTag)) {
                        filteredEvents.add(event);
                        break;
                    }
                }
            }
        }

        return filteredEvents;
    }

     public double calculateEventSocialScore(HangoutRequest event, User currentUser) {
        List<User> participants = event.getParticipants();
        if (participants == null || participants.isEmpty()) return 0.0;

        MatchAlgorithm matchAlgorithm = new MatchAlgorithm();
        int totalScore = 0;
        for (User p : participants) {
            totalScore += matchAlgorithm.calculateMatchScore(currentUser, p);
        }
        return (double) totalScore / participants.size();
    }

    public List<HangoutRequest> getRecommendedEvents(User currentUser) {
        List<HangoutRequest> sortedEvents = new ArrayList<>(events);
        sortedEvents.sort((e1, e2) -> {
            double score1 = calculateEventSocialScore(e1, currentUser);
            double score2 = calculateEventSocialScore(e2, currentUser);
            return Double.compare(score2, score1);
        });
        return sortedEvents;
    }

    public void setEvents(List<HangoutRequest> events) {
        this.events = events;
    }
}