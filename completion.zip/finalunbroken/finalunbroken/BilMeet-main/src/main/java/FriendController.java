import java.io.IOException;
import java.util.List;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Node;

import com.google.cloud.firestore.EventListener;
import com.google.cloud.firestore.FirestoreException;
import com.google.cloud.firestore.ListenerRegistration;
import com.google.cloud.firestore.QuerySnapshot;

public class FriendController {

    private ListenerRegistration friendsListener;

    // ── FXML injections ────────────────────────────────────────────────────────
    
    @FXML private FlowPane friendsContainer; // 2-column badge grid
    @FXML private VBox requestsContainer;    // Used for pending requests overlay
    
    @FXML private Label     statusLabel;

    // Pending badge button (blue dot, shows count)
    @FXML private Button    pendingRequestsBadge;

    // Sidebar
    @FXML private Circle    profileCircle;
    @FXML private Button    profileNameButton;

    // ── Lifecycle ──────────────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        User me = SessionManager.getCurrentUser();
        if (me == null) return;

        // Sidebar badge setup
        if (profileNameButton != null)
            profileNameButton.setText(me.getName() + " " + me.getSurname());
        if (profileCircle != null) {
            String hex = me.getAvatarColor();
            if (hex != null && !hex.isEmpty()) {
                try { profileCircle.setFill(Color.web(hex)); } catch (Exception ignored) {}
            }
        }

        loadFriends(me);
        refreshPendingBadge(me);
        startFriendsListener();
    }

    // ── ASYNC: Friend-request badge count ──────────────────────────────────────
    private void refreshPendingBadge(User me) {
        if (pendingRequestsBadge == null) return;
        
        new Thread(() -> {
            DataManager dm = new DataManager();
            int count = dm.getPendingFriendRequests(me.getEmail()).size();
            
            Platform.runLater(() -> {
                pendingRequestsBadge.setText(String.valueOf(count));
            });
        }).start();
    }

    // ── Show pending requests (blue dot click) ─────────────────────────────────
    @FXML
    public void showPendingRequests(ActionEvent e) throws IOException {
        navigate(e, "/pendingRequestsView.fxml");
    }

    @FXML
    public void openChat(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
        Parent root = loader.load();
        ChatController ctrl = loader.getController();
        ctrl.setManagers(ChatManager.getInstance(), new UserManager());
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    // ── ASYNC: Accept / Reject ─────────────────────────────────────────────────
    public void acceptFriendRequest(FriendRequest request) {
        User me = SessionManager.getCurrentUser();
        if (me == null) { setStatus("Current user not found."); return; }
        
        setStatus("Accepting...");
        
        new Thread(() -> {
            DataManager dm = new DataManager();
            boolean success = dm.acceptFriendRequest(request.getSender().getEmail(), me.getEmail());
            
            if (success) {
                dm.getOrCreatePrivateChat(request.getSender(), me);
            }
            
            Platform.runLater(() -> {
                if (success) {
                    setStatus("Friend request accepted.");
                    loadFriends(me);
                    refreshPendingBadge(me);
                } else {
                    setStatus("Could not accept request.");
                }
            });
        }).start();
    }

    public void rejectFriendRequest(FriendRequest request) {
        User me = SessionManager.getCurrentUser();
        if (me == null) { setStatus("Current user not found."); return; }
        
        setStatus("Rejecting...");
        
        new Thread(() -> {
            DataManager dm = new DataManager();
            boolean success = dm.rejectFriendRequest(request.getSender().getEmail(), me.getEmail());
            
            Platform.runLater(() -> {
                if (success) {
                    setStatus("Friend request rejected.");
                    refreshPendingBadge(me);
                } else {
                    setStatus("Could not reject request.");
                }
            });
        }).start();
    }

    // ── ASYNC: Load friends into FlowPane ──────────────────────────────────────
    public void loadFriends(User user) {
        // Clear immediately so the page opens fast
        if (friendsContainer != null) {
            friendsContainer.getChildren().clear();
            Label loadingLbl = new Label("Loading friends...");
            loadingLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #888888; -fx-padding: 20;");
            friendsContainer.getChildren().add(loadingLbl);
        }

        new Thread(() -> {
            DataManager dm = new DataManager();
            List<User> myFriends = dm.getFriendsForUser(user.getEmail());

            Platform.runLater(() -> {
                user.getFriends().clear();
                user.getFriends().addAll(myFriends);

                if (friendsContainer != null) {
                    friendsContainer.getChildren().clear();
                    
                    if (myFriends.isEmpty()) {
                        Label emptyLbl = new Label("You haven't added any friends yet!");
                        emptyLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #888888; -fx-padding: 20;");
                        friendsContainer.getChildren().add(emptyLbl);
                        return;
                    }
                    myFriends.sort((f1, f2) -> {
                        int score1 = calculateInterestScore(f1, user);
                        int score2 = calculateInterestScore(f2, user);
                        return Integer.compare(score2, score1); // Descending order
                    });

                    try {
                        for (User friend : myFriends) {
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("/friendObject.fxml"));
                            Node card = loader.load();
                            FriendCardController ctrl = loader.getController();
                            ctrl.setData(friend);
                            ctrl.setPreviousPage("/friendView.fxml");
                            friendsContainer.getChildren().add(card);
                        }
                    } catch (IOException e) { e.printStackTrace(); }
                }
            });
        }).start();
    }

    // ── Pending requests box (built in code, added to requestsContainer) ────────
    public void loadPendingRequests(User user) {
        if (requestsContainer != null) requestsContainer.getChildren().clear();

        new Thread(() -> {
            DataManager dm = new DataManager();
            List<FriendRequest> requests = dm.getPendingFriendRequests(user.getEmail());

            Platform.runLater(() -> {
                for (FriendRequest req : requests) {
                    VBox row = new VBox(4);
                    row.setStyle("-fx-background-color: #FFD1DC; -fx-padding: 8; "
                            + "-fx-border-radius: 10; -fx-background-radius: 10;");
                    Label nameLbl  = new Label("From: " + req.getSender().getUserName());
                    Label emailLbl = new Label(req.getSender().getEmail());

                    Button accept = new Button("Accept");
                    accept.setStyle("-fx-background-color: #7ed957; -fx-text-fill: white; -fx-background-radius: 14;");
                    accept.setOnAction(ev -> acceptFriendRequest(req));

                    Button reject = new Button("Reject");
                    reject.setStyle("-fx-background-color: #fe7d7d; -fx-text-fill: white; -fx-background-radius: 14;");
                    reject.setOnAction(ev -> rejectFriendRequest(req));

                    javafx.scene.layout.HBox btns = new javafx.scene.layout.HBox(8, accept, reject);
                    row.getChildren().addAll(nameLbl, emailLbl, btns);
                    if (requestsContainer != null) requestsContainer.getChildren().add(row);
                }
            });
        }).start();
    }

    // ── Firebase real-time listener ────────────────────────────────────────────
    private void startFriendsListener() {
        User me = SessionManager.getCurrentUser();
        if (me == null) return;
        if (friendsListener != null) friendsListener.remove();

        friendsListener = FirebaseInitializer.getFirestore()
                .collection("users")
                .whereEqualTo("userMail", me.getEmail())
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(QuerySnapshot snap, FirestoreException err) {
                        if (err != null) { err.printStackTrace(); return; }
                        // The loadFriends method now handles its own background threading!
                        loadFriends(me);
                    }
                });
    }

    // ── Back / navigation ──────────────────────────────────────────────────────
    @FXML
    public void goBack(ActionEvent e) throws IOException {
        if (friendsListener != null) friendsListener.remove();
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML public void goToProfile(ActionEvent e) throws IOException { navigate(e, "/myProfileUneditable.fxml"); }
    @FXML public void goToMenu(ActionEvent e)    throws IOException { navigate(e, "/AvailableEvents.fxml"); }
    @FXML public void goToSearch(ActionEvent e)  throws IOException { navigate(e, "/searchView.fxml"); }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void openSchedule(javafx.scene.input.MouseEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    // ── Helpers ────────────────────────────────────────────────────────────────
    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
        else System.out.println(msg);
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        if (friendsListener != null) friendsListener.remove();
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    private int calculateInterestScore(User otherUser, User me) {
        if (otherUser.getInterests() == null || me.getInterests() == null) return 0;
        int score = 0;
        for (String theirInterest : otherUser.getInterests()) {
            for (String myInterest : me.getInterests()) {
                if (theirInterest.equalsIgnoreCase(myInterest)) score++;
            }
        }
        return score;
    }
}