import java.util.List;

public class FriendManager {

    private final DataManager dataManager = new DataManager();
    private final ChatManager chatManager = ChatManager.getInstance();

    public FriendRequest sendRequest(User sender, User receiver) {
        boolean ok = dataManager.createFriendRequest(sender, receiver);
        if (!ok) return null;

        FriendRequest request = new FriendRequest(sender);
        receiver.addPendingRequest(request);
        return request;
    }

    public List<User> getFriends(User user) {
        return dataManager.getFriendsForUser(user.getEmail());
    }

    public List<FriendRequest> getPendingRequests(User user) {
        if (user == null) return java.util.Collections.emptyList();
        return dataManager.getPendingFriendRequests(user.getEmail());
    }

    public void acceptRequest(FriendRequest request, User receiver) {
        if (request == null || receiver == null) return;

        boolean updated = dataManager.updateFriendRequestStatus(
                request.getSender().getEmail(),
                receiver.getEmail(),
                "accepted"
        );

        if (updated) {
            dataManager.addFriendToBothUsers(
                    request.getSender().getEmail(),
                    receiver.getEmail()
            );

            dataManager.getOrCreatePrivateChat(request.getSender(), receiver);

            request.accept();
        }
    }

    public void rejectRequest(FriendRequest request, User receiver) {
        if (request == null || receiver == null) return;

        boolean updated = dataManager.updateFriendRequestStatus(
                request.getSender().getEmail(),
                receiver.getEmail(),
                "rejected"
        );

        if (updated) {
            request.reject();
        }
    }
}