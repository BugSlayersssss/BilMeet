import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class LoginController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField mailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label wrongPasswordLabel;

    private DataManager dataManager = new DataManager();

   @FXML
    private void handleLogin(ActionEvent event) {
        String mail = mailField.getText().trim();
        String password = passwordField.getText().trim();

        // Optional: If you have a loading label, you could set it to "Logging in..." here
        wrongPasswordLabel.setVisible(false);

        // Spin up a background thread to talk to Firebase so the UI doesn't freeze
        new Thread(() -> {
            // THIS IS HEAVY: It talks to the internet
            User loggedInUser = dataManager.authenticateAndGetUser(mail, password);

            // Once Firebase replies, jump back to the UI thread to change the screen
            Platform.runLater(() -> {
                if (loggedInUser != null) {
                    SessionManager.setCurrentUser(loggedInUser);
                    try {
                        openProfile(event);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    wrongPasswordLabel.setText("Wrong Email or Password!");
                    wrongPasswordLabel.setVisible(true);
                }
            });
        }).start();
    }
   
    @FXML
    public void openProfile(ActionEvent e) throws IOException {
        System.out.println("Inside openProfile()");
        root = FXMLLoader.load(getClass().getResource("/myProfileUneditable.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    private void goToForgotPassword(ActionEvent event) throws IOException {

    Parent root = FXMLLoader.load(getClass().getResource("/ForgotPassword.fxml"));

    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.setScene(new Scene(root));
    stage.show();
    }

    @FXML
    private void goToSignUp(ActionEvent event) throws IOException{
       
        Parent root = FXMLLoader.load(getClass().getResource("/SignUp.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
       
    }

    
}    
