import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PasswordResetManager {

    // Replace with your real Brevo API key
    private static final String BREVO_API_KEY = "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";

    // Replace with your verified sender email in Brevo
    private static final String SENDER_EMAIL = "bilmeet.bugslayers@gmail.com";
    private static final String SENDER_NAME = "BugSlayers";

    public static String generateCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000);
        return String.valueOf(code);
    }

    public static void saveCodeToFirebase(String email, String code) {
        String safeEmail = email.replace(".", ",");

        long expiresAt = System.currentTimeMillis() + 5 * 60 * 1000;

        DatabaseReference ref = FirebaseDatabase
        .getInstance("https://bilmeet-30953-default-rtdb.firebaseio.com/")
        .getReference("passwordResetCodes")
        .child(safeEmail);

        Map<String, Object> data = new HashMap<String, Object>();
        data.put("code", code);
        data.put("expiresAt", expiresAt);

        ref.setValueAsync(data);
    }

    public static void sendCodeEmail(String toEmail, String code) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        String jsonBody =
                "{"
                + "\"sender\":{\"name\":\"" + SENDER_NAME + "\",\"email\":\"" + SENDER_EMAIL + "\"},"
                + "\"to\":[{\"email\":\"" + toEmail + "\"}],"
                + "\"subject\":\"BilMeet Password Reset Code\","
                + "\"textContent\":\"Your BilMeet verification code is: " + code + ". This code expires in 5 minutes.\""
                + "}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.brevo.com/v3/smtp/email"))
                .header("accept", "application/json")
                .header("api-key", BREVO_API_KEY)
                .header("content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        System.out.println("Brevo status code: " + response.statusCode());
        System.out.println("Brevo response body: " + response.body());

        if (response.statusCode() != 201) {
            throw new RuntimeException("Email sending failed: " + response.body());
        }
    }
}