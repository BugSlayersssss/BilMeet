import java.io.IOException;
import java.util.List;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class PendingRequestsController {

    @FXML
    private VBox requestsContainer;

    @FXML
    private Label statusLabel;

    private final FriendManager friendManager = new FriendManager();
    @FXML
    private Button profileNameButton;

    @FXML
    public void initialize() {
        User currentUser = SessionManager.getCurrentUser();
        if (currentUser != null) {
            loadPendingRequests(currentUser);
        }
        profileNameButton.setText(SessionManager.getCurrentUser().getName()+" "+SessionManager.getCurrentUser().getSurname());
    
    }

   public void loadPendingRequests(User user) {
        // 1. Clear the screen immediately on the main UI thread
        requestsContainer.getChildren().clear();

        // 2. Spin up a background thread for the database query
        new Thread(() -> {
            // THIS IS HEAVY: Fetching from Firebase
            List<FriendRequest> requests = friendManager.getPendingRequests(user);

            // 3. Jump back to the JavaFX thread to draw the UI
            Platform.runLater(() -> {
                if (requests.isEmpty()) {
                    Label emptyLabel = new Label("No pending friend requests.");
                    emptyLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
                    requestsContainer.getChildren().add(emptyLabel);
                    return;
                }

                // Draw the request cards
                for (FriendRequest request : requests) {
                    User sender = request.getSender();
                    HBox row = createRequestRow(sender, request, user);
                    requestsContainer.getChildren().add(row);
                }
            });
        }).start();
    }

    private HBox createRequestRow(User sender, FriendRequest request, User receiver) {
        HBox row = new HBox();
        row.setSpacing(18);
        row.setAlignment(Pos.CENTER_LEFT);

        StackPane profilePane = new StackPane();
        profilePane.setPrefSize(95, 95);
        profilePane.setStyle("-fx-cursor: hand;"); 

        Circle outerCircle = new Circle(46);
        outerCircle.setFill(Color.web(sender.getAvatarColor() != null ? sender.getAvatarColor() : "#F5EFD8"));
        outerCircle.setStroke(Color.BLACK);
        outerCircle.setStrokeWidth(3);

        Label profileIcon = new Label("👤");
        profileIcon.setStyle("-fx-font-size: 42px;");

        profilePane.getChildren().addAll(outerCircle, profileIcon);
        
        // Profile gitme aksiyonu
        profilePane.setOnMouseClicked(e -> {
            try {
                // DOĞRU SIRALAMA
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/strangerProfile-accept-reject.fxml"));

                // 1. Önce FXML'i yükle (Bu işlem kontrolcüyü oluşturur)
                Parent root = loader.load(); 

                // 2. Şimdi kontrolcüyü alabilirsin
                StrangerProfileController ctrl = loader.getController();

                // 3. Veriyi gönder
                ctrl.setUser(sender);

                // 4. Sahneyi göster
                Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        // --- ORTA VE SAG TARAF: KART ---
        HBox card = new HBox();
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPrefHeight(78);
        card.setPrefWidth(420);
        card.setSpacing(18);
        card.setStyle("-fx-background-color: #3FC8D1; -fx-background-radius: 20; -fx-padding: 0 16 0 20;");

        VBox nameBox = new VBox();
        nameBox.setAlignment(Pos.CENTER_LEFT);
        nameBox.setSpacing(2);
        nameBox.setPrefWidth(150);

        Label nameLabel = new Label(sender.getName());
        nameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 17px; -fx-font-weight: bold;");

        Label surnameLabel = new Label(sender.getSurname());
        surnameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 17px; -fx-font-weight: bold;");

        nameBox.getChildren().addAll(nameLabel, surnameLabel);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Butonlar
        Button acceptButton = new Button("✓");
        acceptButton.setPrefSize(64, 64);
        acceptButton.setStyle("-fx-background-color: #95D84B; -fx-background-radius: 100; -fx-text-fill: #7B44D6; -fx-font-size: 28px; -fx-font-weight: bold; -fx-cursor: hand;");

        Button rejectButton = new Button("✕");
        rejectButton.setPrefSize(64, 64);
        rejectButton.setStyle("-fx-background-color: #FF7F87; -fx-background-radius: 100; -fx-text-fill: #5A63D8; -fx-font-size: 24px; -fx-font-weight: bold; -fx-cursor: hand;");

        acceptButton.setOnAction(e -> {
            friendManager.acceptRequest(request, receiver);
            setStatus("Friend request accepted.");
            loadPendingRequests(receiver);
        });

        rejectButton.setOnAction(e -> {
            friendManager.rejectRequest(request, receiver);
            setStatus("Friend request rejected.");
            loadPendingRequests(receiver);
        });

        card.getChildren().addAll(nameBox, spacer, acceptButton, rejectButton);
        row.getChildren().addAll(profilePane, card);

        return row;
    }
    @FXML
    public void goBackToFriends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/friendView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToMenu(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/AvailableEvents.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToChat(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Chat.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToSchedule(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToCreateEventScreen(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/createEvent.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToFriends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/friendView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToProfile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/myProfileUneditable.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public void goToSearch(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/searchView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    private void setStatus(String text) {
        if (statusLabel != null) {
            statusLabel.setText(text);
        } else {
            System.out.println(text);
        }
    }
}