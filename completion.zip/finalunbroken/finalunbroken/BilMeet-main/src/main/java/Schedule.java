public class Schedule {

    private boolean[][] availabilityMatrix;

    // ── Constructor ────────────────────────────────────────────────────────────
    public Schedule() {
        this.availabilityMatrix = new boolean[7][24];
    }

    // ── Slot toggling (used by the original schedule logic) ────────────────────
    public void setAvailability(int day, int hour, boolean isFree) {
        if (isValidSlot(day, hour)) {
            availabilityMatrix[day][hour] = isFree;
        }
    }

    /**
     * Returns true when the user is FREE for the entire event window.
     * A slot is considered BUSY when availabilityMatrix[day][hour] == true.
     */
    public boolean isAvailableForEvent(int dayIndex, int startHour, int endHour) {
        if (dayIndex < 0 || dayIndex > 6) return false;
        for (int i = startHour; i < endHour; i++) {
            if (availabilityMatrix[dayIndex][i]) return false; // busy
        }
        return true;
    }

    // ── Bulk get/set used by ScheduleController ────────────────────────────────

    /**
     * Returns a direct reference to the 7×24 busy-slots matrix.
     * Index: [dayOfWeek 0=Mon…6=Sun][hour 0–23]
     * true = BUSY, false = FREE.
     */
    public boolean[][] getBusySlots() {
        return availabilityMatrix;
    }

    /**
     * Replaces the entire matrix (used when restoring a saved schedule).
     * A defensive copy is made so external changes don't corrupt internal state.
     */
    public void setBusySlots(boolean[][] slots) {
        if (slots == null) return;
        for (int d = 0; d < Math.min(7, slots.length); d++) {
            for (int h = 0; h < Math.min(24, slots[d].length); h++) {
                availabilityMatrix[d][h] = slots[d][h];
            }
        }
    }

    // ── Private helpers ────────────────────────────────────────────────────────
    private boolean isValidSlot(int day, int hour) {
        return day >= 0 && day < 7 && hour >= 0 && hour < 24;
    }
}
