import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ScheduleController {

    @FXML
    private GridPane scheduleGrid;

    @FXML
    private Button editToggleButton;
    
    @FXML
    private Button profileNameButton;

    // We no longer hardcode 7x15; we use the reference from the User object
    private boolean[][] busySlots; 
    
    private final String[] DAYS = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
    
    private final String FREE_STYLE = "-fx-background-color: #A5D6A7; -fx-border-color: #81C784; -fx-border-radius: 5; -fx-background-radius: 5; -fx-cursor: hand;";
    private final String BUSY_STYLE = "-fx-background-color: #EF9A9A; -fx-border-color: #E57373; -fx-border-radius: 5; -fx-background-radius: 5; -fx-cursor: hand;";
    
    private final String HEADER_STYLE = "-fx-background-color: #1a365d; " +
                                       "-fx-text-fill: white; " +
                                       "-fx-font-weight: bold; " +
                                       "-fx-alignment: center; " +
                                       "-fx-background-radius: 5;";

    @FXML
    public void initialize() {
        User me = SessionManager.getCurrentUser();
        
        // Load the actual 7x24 schedule from the logged-in user
        if (me != null && me.getSchedule() != null) {
            this.busySlots = me.getSchedule().getBusySlots();
        } else {
            this.busySlots = new boolean[7][24];
        }

        buildGrid();
        
        if (profileNameButton != null && me != null) {
            profileNameButton.setText(me.getName() + " " + me.getSurname());
        }
    }

    private void buildGrid() {
        scheduleGrid.getChildren().clear();
        scheduleGrid.setAlignment(Pos.CENTER);

        // Day Headers (Top Row)
        for (int col = 0; col < 7; col++) {
            Label dayLabel = new Label(DAYS[col]);
            dayLabel.setPrefSize(90, 35);
            dayLabel.setStyle(HEADER_STYLE);
            scheduleGrid.add(dayLabel, col + 1, 0); 
        }

        // Loop 24 times for the full 24-hour day (Left Column)
        for (int row = 0; row < 24; row++) { 
            String timeText = String.format("%02d:00", row); // Renders 00:00 to 23:00
            
            Label timeLabel = new Label(timeText);
            timeLabel.setPrefSize(75, 35);
            timeLabel.setStyle(HEADER_STYLE);
            scheduleGrid.add(timeLabel, 0, row + 1);

            for (int col = 0; col < 7; col++) {
                Button slotButton = new Button();
                slotButton.setPrefSize(90, 35);
                
                // Color it based on the loaded schedule data
                if (busySlots[col][row]) {
                    slotButton.setStyle(BUSY_STYLE);
                } else {
                    slotButton.setStyle(FREE_STYLE);
                }
                
                final int finalCol = col;
                final int finalRow = row;
                slotButton.setOnAction(e -> handleSlotClick(finalCol, finalRow, slotButton));
                scheduleGrid.add(slotButton, col + 1, row + 1);
            }
        }
    }

    private void handleSlotClick(int dayIndex, int hourIndex, Button clickedButton) {
        busySlots[dayIndex][hourIndex] = !busySlots[dayIndex][hourIndex];
        
        if (busySlots[dayIndex][hourIndex]) {
            clickedButton.setStyle(BUSY_STYLE);
        } else {
            clickedButton.setStyle(FREE_STYLE);
        }
        
        System.out.println(DAYS[dayIndex] + " " + String.format("%02d:00", hourIndex) + " -> " + 
                          (busySlots[dayIndex][hourIndex] ? "BUSY" : "FREE"));
    }

    @FXML
    public void handleSaveSchedule(ActionEvent event) {
        User me = SessionManager.getCurrentUser();
        if (me != null) {
            // Save the grid data back into the User object in memory
            me.getSchedule().setBusySlots(busySlots);
            
            // Save the data to Firebase using the method in DataManager
            DataManager dm = new DataManager();
            dm.saveSchedule(me.getEmail(), busySlots);
            
            System.out.println("Schedule saved successfully to Firebase!");
        }
    }

    @FXML
    public void handleToggleEdit(ActionEvent event) {
        System.out.println("Editing mode toggled.");
    }

    // ── Navigation Methods ─────────────────────────────────────────────────────

    @FXML
    public void openChat(ActionEvent e) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Chat.fxml"));
            Parent root = loader.load();
            
            ChatController ctrl = loader.getController();
            if (ctrl != null) {
                ctrl.setManagers(ChatManager.getInstance(), new UserManager());
            }

            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            
        } catch (IOException ex) {
            System.err.println("FXML Yüklenemedi: " + ex.getMessage());
            ex.printStackTrace();
        } catch (ClassCastException ex) {
            System.err.println("Tıklanan nesne bir Node değil!");
        }
    }

    @FXML
    public void goToProfile(ActionEvent e) throws IOException {
        navigate(e, "/myProfileUneditable.fxml");
    }

    @FXML
    public void goToMenu(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    @FXML
    public void goToFriends(ActionEvent e) throws IOException {
        navigate(e, "/friendView.fxml");
    }

    @FXML
    public void goToSearch(ActionEvent e) throws IOException {
        navigate(e, "/searchView.fxml");
    }

    @FXML
    public void goToCreateEventScreen(ActionEvent e) throws IOException {
        navigate(e, "/createEvent.fxml");
    }

    @FXML
    public void openSchedule(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Schedule.fxml"));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    public void goBack(ActionEvent e) throws IOException {
        navigate(e, "/AvailableEvents.fxml");
    }

    private void navigate(ActionEvent e, String fxml) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxml));
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}