import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController {

    private final DataManager dataManager = new DataManager();

    @FXML private TextField mailField;
    @FXML private TextField nameField;
    @FXML private TextField surnameField;
    @FXML private TextField deptField;

    // FXML now uses PasswordField (not TextField) for the password input
    @FXML private PasswordField createPasswordField;

    // Error label injected from SignUp.fxml (fx:id="errorLabel")
    @FXML private Label errorLabel;

    // ── Back arrow ─────────────────────────────────────────────────────────────
    @FXML
    private void goBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/LoginNew.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

  // ── Sign Up button ─────────────────────────────────────────────────────────
    @FXML
    private void handleSignUp(ActionEvent event) {
        String email      = mailField.getText().trim();
        String name       = nameField.getText().trim();
        String surname    = surnameField.getText().trim();
        String department = deptField.getText().trim();
        String password   = createPasswordField.getText().trim();

        // UI-visible validation (instant, stays on UI thread)
        if (email.isEmpty() || name.isEmpty() || surname.isEmpty()
                || department.isEmpty() || password.isEmpty()) {
            setError("Please fill all fields.");
            return;
        }

        if (!email.endsWith("@ug.bilkent.edu.tr")) {
            setError("Please use your Bilkent email (@ug.bilkent.edu.tr).");
            return;
        }

        // Give the user instant feedback that the button worked
        setError("Creating account, please wait...");

        // Push the database check/creation to a background thread
        new Thread(() -> {
            // HEAVY: Checks if user exists, generates ID, saves to Firebase
            boolean created = dataManager.createUser(name, surname, department, password, email);

            // Jump back to the UI thread
            Platform.runLater(() -> {
                if (created) {
                    setError("Account created successfully!");
                    try {
                        goBackToLogin(event); // Redirect to login
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    setError("This email is already registered.");
                }
            });
        }).start();
    }

    private void setError(String msg) {
        if (errorLabel != null) errorLabel.setText(msg);
        else System.out.println(msg);
    }
}
