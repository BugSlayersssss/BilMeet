import java.util.ArrayList;
import java.util.List;

public class User {

    // Basic Profile Information
    private String userId;
    private String name;
    private String surname;
    private String email;
    private String password;
    private String department;

    // Avatar colour stored as a CSS hex string, e.g. "#C8A0C8"
    private String avatarColor = "#C8A0C8";   // default: soft purple

    // Lists for relationships, interests, and events
    private List<String>        interests;
    private List<Integer>       userInterestCodes;
    private List<User>          friends;
    private List<FriendRequest> friendRequests;
    private List<HangoutRequest> eventHistory;
    private List<HangoutRequest> organizedEvents;

    // User's schedule matrix
    private Schedule schedule;

    // Predefined interest arrays
    public final int[]    availableInterestCodes = {0,1,2,3,4,5,6,7,8,9,10,11,12};
    public final String[] availableInterestNames = {
        "Books","Music","Baking","Volleyball","Football","Movies",
        "Comic Books","Drawing","Video Games","Cat Person","Dog Person",
        "Basketball","Mentoring"
    };

    // ── Constructor ────────────────────────────────────────────────────────────
    public User(String name, String surname, String email,
                String password, String department) {
        this.name       = name;
        this.surname    = surname;
        this.email      = email;
        this.password   = password;
        this.department = department;

        this.interests         = new ArrayList<>();
        this.userInterestCodes = new ArrayList<>();
        this.friends           = new ArrayList<>();
        this.friendRequests    = new ArrayList<>();
        this.eventHistory      = new ArrayList<>();
        this.organizedEvents   = new ArrayList<>();
        this.schedule          = new Schedule();
    }

    // ── Profile Management ─────────────────────────────────────────────────────
    public void updateProfile(String newName, String newSurname, String newDept) {
        this.name       = newName;
        this.surname    = newSurname;
        this.department = newDept;
    }

    // ── Adder Methods ──────────────────────────────────────────────────────────
    public void addOrganizedEvent(HangoutRequest event) {
        if (!organizedEvents.contains(event)) organizedEvents.add(event);
    }
    public void addInterest(String interest) {
        if (!interests.contains(interest)) interests.add(interest);
    }
    public void addFriend(User newFriend) {
        if (!friends.contains(newFriend)) friends.add(newFriend);
    }
    public void addPendingRequest(FriendRequest fr) { friendRequests.add(fr); }

    // ── Remover Methods ────────────────────────────────────────────────────────
    public void removeFriend(User friend)     { friends.remove(friend); }
    public void removeInterest(String interest) { interests.remove(interest); }

    // ── Getters ────────────────────────────────────────────────────────────────
    public String getUserId()     { return userId; }

    /**
     * Convenience alias used by UI controllers.
     * Returns userId; falls back to email prefix if userId is null.
     */
    public String getId() {
        return (userId != null && !userId.isEmpty()) ? userId
                : (email != null ? email.split("@")[0] : "");
    }

    public String getName()       { return name; }
    public String getSurname()    { return surname; }
    public String getEmail()      { return email; }
    public String getPassword()   { return password; }
    public String getDepartment() { return department; }

    /** Full display name "First Last". */
    public String getUserName() { return name + " " + surname; }

    public Schedule          getSchedule()         { return schedule; }
    public List<String>      getInterests()         { return interests; }
    public List<Integer>     getUserInterestCodes() { return userInterestCodes; }
    public List<User>        getFriends()           { return friends; }
    public ArrayList<User>   getUserFriends()       { return new ArrayList<>(friends); }
    public String            getUserPassword()      { return password; }
    public ArrayList<String> getUserInterests()     { return new ArrayList<>(interests); }

    public List<HangoutRequest> getEventHistory()    { return eventHistory; }
    public List<HangoutRequest> getOrganizedEvents() { return organizedEvents; }

    /**
     * Returns the avatar colour hex string (e.g. "#C8A0C8").
     * Never null – returns the default if none was set.
     */
    public String getAvatarColor() {
        return (avatarColor != null && !avatarColor.isEmpty()) ? avatarColor : "#C8A0C8";
    }

    // ── Setters ────────────────────────────────────────────────────────────────
    public void setUserId(String userId)       { this.userId = userId; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }

    /**
     * Stores the chosen avatar colour as a CSS hex string.
     * @param hex e.g. "#4DD9D9" or "#E8C240"
     */
    public void setAvatarColor(String hex)     { this.avatarColor = hex; }

    // ── Utility ────────────────────────────────────────────────────────────────
    public void renderUser() {
        System.out.println("Rendering user: " + getUserName());
    }
}
